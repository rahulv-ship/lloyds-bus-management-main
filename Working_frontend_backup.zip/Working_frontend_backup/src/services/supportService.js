import api from './api'

export async function submitSupportTicket({ subject, message, priority = 'medium' }) {
  const res = await api.post('/support/ticket', { subject, message, priority })
  return res.data
}
