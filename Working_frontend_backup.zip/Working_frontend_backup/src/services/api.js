import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  timeout: 15000,
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('lloyds_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.code === 'ECONNABORTED') {
      error.message = 'Request timed out. Is the backend running on port 5000?'
      return Promise.reject(error)
    }
    if (!error.response) {
      error.message = 'Cannot reach the server. Make sure the backend is running on port 5000.'
      return Promise.reject(error)
    }
    return Promise.reject(error)
  }
)

export default api
