import api from './api'

export async function fetchBusTiming() {
  const res = await api.get('/bus-timing/timing')
  return res.data
}
