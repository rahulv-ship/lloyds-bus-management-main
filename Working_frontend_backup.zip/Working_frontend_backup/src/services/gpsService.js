import api from './api'

const BUS_META = {
  'MH34CQ3491': { route: 'Route 1 / Shift A', shift: 'Shift A', driver: 'S. Kumar', eta: '08:15 AM', occupancy: 78 },
  'MH34CQ3605': { route: 'Route 2 / General', shift: 'General', driver: 'R. Sharma', eta: '09:20 AM', occupancy: 62 },
  'MH34CQ3604': { route: 'Route 3 / General', shift: 'General', driver: 'A. Patel', eta: '10:45 AM', occupancy: 55 },
  'MH34CQ3492': { route: 'Route 1 / General', shift: 'General', driver: 'M. Singh', eta: '08:20 AM', occupancy: 91 },
  'MH34CQ3603': { route: 'Route 4 / General', shift: 'General', driver: 'K. Reddy', eta: '11:45 AM', occupancy: 47 },
  'MH34CQ3198': { route: 'Route 5 / General', shift: 'General', driver: 'V. Rao', eta: '12:10 PM', occupancy: 69 },
}

const WHEELSEYE_API_URL = 'https://api.wheelseye.com/currentLoc?accessToken=98a3355b-4498-48bb-8b70-7b0b04475788'

export async function fetchWheelseyeVehicles() {
  const res = await api.get('/vehicles')
  const data = res.data?.data?.list || []

  return data.map((v, idx) => {
    const meta = BUS_META[v.vehicleNumber] || {
      route: v.venndorName || 'Route',
      shift: v.vehicleType || 'General',
      driver: 'Unassigned',
      eta: '—',
      occupancy: 0
    }
    const isMoving = v.speed > 0 && v.ignition
    return {
      bus_id: idx + 1,
      bus_number: v.vehicleNumber,
      route: meta.route,
      shift: meta.shift,
      status: isMoving ? 'ACTIVE' : 'INACTIVE',
      lat: v.latitude,
      lng: v.longitude,
      speed: Math.round(v.speed),
      driver: meta.driver,
      eta: meta.eta,
      occupancy: meta.occupancy,
      raw: v
    }
  })
}

export async function fetchWheelseyeDirect() {
  const res = await fetch(WHEELSEYE_API_URL, {
    method: 'GET',
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(12000)
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(body.message || `Wheelseye API returned HTTP ${res.status}`)
  }
  const list = body?.data?.list || body?.data?.list || body?.list || []
  return list.map((v, idx) => {
    const meta = BUS_META[v.vehicleNumber] || {
      route: v.venndorName || 'Route',
      shift: v.vehicleType || 'General',
      driver: 'Unassigned',
      eta: '—',
      occupancy: 0
    }
    const isMoving = v.speed > 0 && v.ignition
    return {
      bus_id: idx + 1,
      bus_number: v.vehicleNumber,
      route: meta.route,
      shift: meta.shift,
      status: isMoving ? 'ACTIVE' : 'INACTIVE',
      lat: v.latitude,
      lng: v.longitude,
      speed: Math.round(v.speed),
      driver: meta.driver,
      eta: meta.eta,
      occupancy: meta.occupancy,
      raw: v
    }
  })
}

export async function getConfig() {
  const res = await api.get('/config')
  return res.data
}

export function startWheelseyePolling(onUpdate, intervalMs = 30000) {
  const tick = async () => {
    try {
      const vehicles = await fetchWheelseyeVehicles()
      onUpdate(vehicles)
    } catch (e) {
      console.error('Wheelseye poll failed:', e)
    }
  }
  tick()
  const id = setInterval(tick, intervalMs)
  return () => clearInterval(id)
}
