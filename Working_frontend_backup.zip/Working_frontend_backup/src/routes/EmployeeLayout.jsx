import { useEffect, useMemo, useRef } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import AppHeader from '../components/layout/AppHeader'
// import './NewLayout.css'

const TITLES = {
   '/app/home': 'Home',
  '/app/book': 'Book Bus',
  '/app/pass': 'My Pass',
  '/app/bookings': 'My Bookings',
  '/app/notifications': 'Notifications',
  '/app/alerts': 'Alerts',
  '/app/profile': 'Profile',
  '/app/settings': 'Settings',
}

export default function EmployeeLayout() {
  const location = useLocation()
  const mainRef = useRef(null)

  const title = useMemo(() => {
    const path = location.pathname
    if (TITLES[path]) return TITLES[path]
    const match = Object.keys(TITLES)
      .filter((k) => path.startsWith(k))
      .sort((a, b) => b.length - a.length)[0]
    return match ? TITLES[match] : 'Employee Transport'
  }, [location.pathname])

  useEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' })
    }
    window.scrollTo({ top: 0, behavior: 'auto' })
  }, [location.pathname])

  return (
    <div className="app-shell">
      <div className="app-shell__content">
        <AppHeader />
        <main ref={mainRef} className="app-shell__main">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
