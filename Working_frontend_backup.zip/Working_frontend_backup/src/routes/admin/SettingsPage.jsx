import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
// import '#ef4444;'

export default function SettingsPage() {
  const navigate = useNavigate()

  return (
    <div className="admin-page">
      <div className="admin-page__header">
        <div className="admin-page__header-left">
          <button type="button" className="admin-page__back" onClick={() => navigate(-1)}>
            <ArrowLeft size={16} />
            <span>Back</span>
          </button>
          <div className="admin-page__titles">
            <h1>Settings</h1>
            <p className="page-subtitle">Manage your account preferences and notification settings.</p>
          </div>
        </div>
      </div>

      <div className="admin-page__inner">
        <div className="admin-page__scroll">
          <div className="card">
            <h2>Account Settings</h2>
            <p>Account preferences and settings will be available here.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
