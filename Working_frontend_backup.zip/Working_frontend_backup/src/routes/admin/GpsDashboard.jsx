import { useState, useEffect, useMemo, useCallback } from 'react'
import {
  MapPin, Navigation, Activity, Clock, Zap,
  Bus, Users, Gauge, Radio, TrendingUp, Signal, ArrowLeft,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import {
  MapContainer, TileLayer, Marker, Popup,
  Polyline, Circle, useMap,
} from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import AlertModal from '../../components/common/AlertModal'
import { fetchWheelseyeVehicles, startWheelseyePolling } from '../../services/gpsService'
import './GpsDashboard.css'

/* ============================================================
   SAMPLE DATA — based on master report buses and services
   ============================================================ */
const ROUTE_COORDS = [
  [19.9445, 79.2880],
  [19.9460, 79.3100],
  [19.9480, 79.2850],
  [19.9510, 79.3020],
  [19.9530, 79.2980],
  [19.9555, 79.3120],
  [19.9580, 79.2920],
  [19.9615, 79.2961],
  [19.9650, 79.3080],
  [19.9680, 79.2900],
  [19.9690, 79.3150],
  [19.9720, 79.3055],
  [19.9750, 79.3010],
  [19.9780, 79.2950],
]

function MapController({ center, zoom = 13 }) {
  const map = useMap()
  useEffect(() => {
    if (center) map.flyTo(center, zoom, { duration: 1.4, easeLinearity: 0.25 })
  }, [center, zoom, map])
  return null
}

const createBusIcon = (bus) => {
  const isActive = bus.status === 'ACTIVE'
  const color = isActive ? '#1b5e8a' : '#c1443a'
  const pulse = isActive ? 'rgba(27,94,138,0.45)' : 'rgba(193,68,58,0.4)'
  return L.divIcon({
    className: 'gps-marker',
    html: `
      <div class="gps-marker__pulse" style="border-color:${color}; background:${pulse};"></div>
      <div class="gps-marker__inner" style="background:linear-gradient(135deg, ${color} 0%, ${isActive ? '#2e7bb3' : '#d96a60'} 100%);">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M8 6v6"></path>
          <path d="M15 6v6"></path>
          <path d="M12 6v12"></path>
          <rect x="4" y="4" width="16" height="16" rx="2"></rect>
        </svg>
      </div>
      <div class="gps-marker__label">${bus.bus_number}</div>
    `,
    iconSize: [44, 56],
    iconAnchor: [22, 28],
  })
}

const statusColor = (s) => (s === 'ACTIVE' ? '#1b5e8a' : '#c1443a')

export default function GpsDashboard() {
  const navigate = useNavigate()
  const [buses, setBuses] = useState([])
  const [error, setError] = useState('')
  const [showError, setShowError] = useState(false)
  const [selectedBus, setSelectedBus] = useState(null)
  const [mapCenter, setMapCenter] = useState([19.9615, 79.2961])
  const [filter, setFilter] = useState('ALL')

  const loadVehicles = useCallback(async () => {
    try {
      const data = await fetchWheelseyeVehicles()
      setBuses(data)
    } catch (e) {
      setError(e.response?.data?.message || e.message)
      setShowError(true)
    }
  }, [])

  useEffect(() => {
    loadVehicles()
    const stopPolling = startWheelseyePolling(setBuses, 30000)
    return stopPolling
  }, [loadVehicles])

  const activeBuses = useMemo(() => buses.filter((b) => b.status === 'ACTIVE'), [buses])
  const inactiveBuses = useMemo(() => buses.filter((b) => b.status !== 'ACTIVE'), [buses])
  const avgSpeed = useMemo(() => {
    if (!activeBuses.length) return 0
    return Math.round(activeBuses.reduce((s, b) => s + b.speed, 0) / activeBuses.length)
  }, [activeBuses])
  const totalDrivers = useMemo(() => new Set(buses.map((b) => b.driver)).size, [buses])
  const avgOccupancy = useMemo(() => {
    const w = activeBuses.filter((b) => b.occupancy > 0)
    if (!w.length) return 0
    return Math.round(w.reduce((s, b) => s + b.occupancy, 0) / w.length)
  }, [activeBuses])

  const filteredBuses = useMemo(() => {
    if (filter === 'ACTIVE') return activeBuses
    if (filter === 'INACTIVE') return inactiveBuses
    return buses
  }, [filter, buses, activeBuses, inactiveBuses])

  const handleSelectBus = (bus) => {
    setSelectedBus(bus)
    setMapCenter([bus.lat, bus.lng])
  }

  return (
    <div className="gps-dashboard gps-dashboard--fullscreen">
      <AlertModal
        open={showError}
        title="Something went wrong"
        message={error}
        confirmLabel="Close"
        onConfirm={() => setShowError(false)}
      />

      {/* ============ HEADER ============ */}
      <header className="page-header">
        <div className="page-header__left">
          <button
            type="button"
            className="gps-back-btn"
            onClick={() => navigate(-1)}
            aria-label="Go back"
          >
            <ArrowLeft size={18} />
            <span>Back</span>
          </button>
          <div className="page-header__badge">
            <Radio size={14} className="pulse-dot" />
            LIVE
          </div>
          <div className="page-header__titles">
            <h1>GPS Fleet Dashboard</h1>
            <p className="page-subtitle">
              Real-time bus tracking · Chandrapur Plant Operations
            </p>
          </div>
        </div>

        <div className="gps-header-stats">
          <div className="gps-stat-pill gps-stat-pill--active">
            <Activity size={16} />
            <div className="gps-stat-pill__text">
              <span className="gps-stat-pill__value">{activeBuses.length}</span>
              <span className="gps-stat-pill__label">Active</span>
            </div>
          </div>
          <div className="gps-stat-pill gps-stat-pill--speed">
            <Zap size={16} />
            <div className="gps-stat-pill__text">
              <span className="gps-stat-pill__value">{avgSpeed}</span>
              <span className="gps-stat-pill__label">km/h avg</span>
            </div>
          </div>
          <div className="gps-stat-pill gps-stat-pill--drivers">
            <Users size={16} />
            <div className="gps-stat-pill__text">
              <span className="gps-stat-pill__value">{totalDrivers}</span>
              <span className="gps-stat-pill__label">Drivers</span>
            </div>
          </div>
          <div className="gps-stat-pill gps-stat-pill--occupancy">
            <TrendingUp size={16} />
            <div className="gps-stat-pill__text">
              <span className="gps-stat-pill__value">{avgOccupancy}%</span>
              <span className="gps-stat-pill__label">Occupancy</span>
            </div>
          </div>
        </div>
      </header>

      {/* ============ MAIN LAYOUT ============ */}
      <div className="gps-layout">
        <div className="gps-map">
          <MapContainer
            center={mapCenter}
            zoom={13}
            className="gps-leaflet-map"
            zoomControl={false}
            scrollWheelZoom
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              maxZoom={19}
            />
            <MapController center={mapCenter} />

            <Polyline
              positions={ROUTE_COORDS}
              pathOptions={{ color: '#1b5e8a', weight: 10, opacity: 0.12, lineCap: 'round' }}
            />
            <Polyline
              positions={ROUTE_COORDS}
              pathOptions={{
                color: '#1b5e8a', weight: 4, opacity: 0.85,
                dashArray: '10 8', lineCap: 'round',
              }}
            />

            {activeBuses.map((bus) => (
              <Circle
                key={`halo-${bus.bus_id}`}
                center={[bus.lat, bus.lng]}
                radius={180}
                pathOptions={{
                  color: '#1b5e8a', fillColor: '#1b5e8a',
                  fillOpacity: 0.08, weight: 0,
                }}
              />
            ))}

            {buses.map((bus) => (
              <Marker
                key={bus.bus_id}
                position={[bus.lat, bus.lng]}
                icon={createBusIcon(bus)}
                eventHandlers={{ click: () => handleSelectBus(bus) }}
              >
                <Popup className="gps-popup-wrapper" closeButton={false}>
                  <div className="gps-popup">
                    <div className="gps-popup__head">
                      <span className="gps-popup__dot" style={{ background: statusColor(bus.status) }} />
                      <b>{bus.bus_number}</b>
                      <span className={`gps-popup__status gps-popup__status--${bus.status.toLowerCase()}`}>
                        {bus.status}
                      </span>
                    </div>
                    <div className="gps-popup__route">{bus.route}</div>
                    <div className="gps-popup__grid">
                      <div><span>Shift</span><b>{bus.shift}</b></div>
                      <div><span>Driver</span><b>{bus.driver}</b></div>
                      <div><span>ETA</span><b>{bus.eta}</b></div>
                      <div><span>Speed</span><b>{bus.speed} km/h</b></div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>

          <div className="gps-map__overlay gps-map__overlay--legend">
            <div className="gps-map__legend">
              <div className="gps-map__legend-title">Legend</div>
              <div className="gps-legend-item">
                <span className="gps-legend-dot gps-legend-dot--active" />
                <span>Active bus</span>
              </div>
              <div className="gps-legend-item">
                <span className="gps-legend-dot gps-legend-dot--inactive" />
                <span>Inactive</span>
              </div>
              <div className="gps-legend-item">
                <span className="gps-legend-line" />
                <span>Route</span>
              </div>
            </div>
          </div>

          <div className="gps-map__overlay gps-map__overlay--live">
            <div className="gps-live-badge">
              <span className="gps-live-badge__pulse" />
              Live tracking
            </div>
          </div>
        </div>

        <aside className="gps-sidebar">
          <div className="gps-sidebar__card">
            <div className="gps-sidebar__header">
              <h2>
                <Bus size={18} />
                Fleet Status
              </h2>
              <span className="gps-sidebar__count">{filteredBuses.length} vehicles</span>
            </div>

            <div className="gps-filters">
              {[
                { key: 'ALL', label: 'All', count: buses.length },
                { key: 'ACTIVE', label: 'Active', count: activeBuses.length },
                { key: 'INACTIVE', label: 'Inactive', count: inactiveBuses.length },
              ].map((f) => (
                <button
                  key={f.key}
                  className={`gps-filter ${filter === f.key ? 'gps-filter--active' : ''}`}
                  onClick={() => setFilter(f.key)}
                >
                  {f.label}
                  <span className="gps-filter__count">{f.count}</span>
                </button>
              ))}
            </div>

            <div className="gps-bus-list">
              {filteredBuses.map((bus) => {
                const isActive = bus.status === 'ACTIVE'
                return (
                  <div
                    key={bus.bus_id}
                    className={`gps-bus-item ${selectedBus?.bus_id === bus.bus_id ? 'gps-bus-item--selected' : ''}`}
                    onClick={() => handleSelectBus(bus)}
                  >
                    <div className="gps-bus-item__header">
                      <div className={`gps-bus-dot ${isActive ? 'gps-bus-dot--active' : 'gps-bus-dot--inactive'}`} />
                      <div className="gps-bus-item__title">
                        <b>{bus.bus_number}</b>
                        <span>{bus.shift} · {bus.route}</span>
                      </div>
                      <span className={`gps-status gps-status--${bus.status.toLowerCase()}`}>
                        {bus.status}
                      </span>
                    </div>

                    <div className="gps-bus-item__meta">
                      <span className="gps-location">
                        <MapPin size={13} />
                        {bus.lat.toFixed(4)}, {bus.lng.toFixed(4)}
                      </span>
                      <span className="gps-speed">
                        <Navigation size={13} />
                        {bus.speed} km/h
                      </span>
                    </div>

                    <div className="gps-bus-item__footer">
                      <span className="gps-driver">
                        <Users size={13} />
                        {bus.driver}
                      </span>
                      <span className="gps-eta">
                        <Clock size={13} />
                        ETA {bus.eta}
                      </span>
                    </div>

                    {isActive && bus.occupancy > 0 && (
                      <div className="gps-occupancy">
                        <div className="gps-occupancy__label">
                          <Gauge size={12} />
                          <span>Occupancy</span>
                          <b>{bus.occupancy}%</b>
                        </div>
                        <div className="gps-occupancy__track">
                          <div
                            className="gps-occupancy__fill"
                            style={{
                              width: `${bus.occupancy}%`,
                              background: bus.occupancy > 85
                                ? 'linear-gradient(90deg,#f59e0b,#ef4444)'
                                : 'linear-gradient(90deg,#1b5e8a,#2e7bb3)',
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}

              {!filteredBuses.length && (
                <div className="gps-empty">
                  <Signal size={28} />
                  <p>No buses match this filter.</p>
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}