import { useEffect, useMemo, useState } from 'react'
import api from '../../services/api'
import Button from '../../components/common/Button'
import Notice from '../../components/common/Notice'
import StatusBadge from '../../components/common/StatusBadge'

const TABLE_CONFIG = {
  buses: {
    label: 'Buses',
    columns: [
      { key: 'bus_number', label: 'Bus Number' },
      { key: 'registration_number', label: 'Registration' },
      { key: 'seating_capacity', label: 'Seats' },
      { key: 'vendor.vendor_name', label: 'Vendor' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => {
      if (key.includes('.')) {
        return key.split('.').reduce((obj, k) => (obj && obj[k]), row) || '—'
      }
      return row[key] ?? '—'
    },
  },
  routes: {
    label: 'Routes',
    columns: [
      { key: 'route_number', label: 'Route No.' },
      { key: 'route_name', label: 'Route Name' },
      { key: 'source', label: 'Source' },
      { key: 'destination', label: 'Destination' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => row[key] ?? '—',
  },
  stops: {
    label: 'Stops',
    columns: [
      { key: 'stop_code', label: 'Code' },
      { key: 'stop_name', label: 'Stop Name' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => row[key] ?? '—',
  },
  shifts: {
    label: 'Shifts',
    columns: [
      { key: 'shift_code', label: 'Code' },
      { key: 'shift_name', label: 'Shift Name' },
      { key: 'start_time', label: 'Start Time' },
      { key: 'end_time', label: 'End Time' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => row[key] ?? '—',
  },
  vendors: {
    label: 'Vendors',
    columns: [
      { key: 'vendor_code', label: 'Code' },
      { key: 'vendor_name', label: 'Vendor Name' },
      { key: 'mobile', label: 'Mobile' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => row[key] ?? '—',
  },
  drivers: {
    label: 'Drivers',
    columns: [
      { key: 'driver_code', label: 'Code' },
      { key: 'driver_name', label: 'Name' },
      { key: 'mobile', label: 'Mobile' },
      { key: 'bus.bus_number', label: 'Bus' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => {
      if (key.includes('.')) {
        return key.split('.').reduce((obj, k) => (obj && obj[k]), row) || '—'
      }
      return row[key] ?? '—'
    },
  },
  conductors: {
    label: 'Conductors',
    columns: [
      { key: 'conductor_code', label: 'Code' },
      { key: 'conductor_name', label: 'Name' },
      { key: 'mobile', label: 'Mobile' },
      { key: 'bus.bus_number', label: 'Bus' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => {
      if (key.includes('.')) {
        return key.split('.').reduce((obj, k) => (obj && obj[k]), row) || '—'
      }
      return row[key] ?? '—'
    },
  },
  services: {
    label: 'Services',
    columns: [
      { key: 'bus.bus_number', label: 'Bus' },
      { key: 'route.route_number', label: 'Route' },
      { key: 'shift.shift_name', label: 'Shift' },
      { key: 'employee_capacity', label: 'Capacity' },
      { key: 'status', label: 'Status', type: 'status' },
    ],
    getValue: (row, key) => {
      if (key.includes('.')) {
        return key.split('.').reduce((obj, k) => (obj && obj[k]), row) || '—'
      }
      return row[key] ?? '—'
    },
  },
}

export default function MasterReportPage() {
  const [r, setR] = useState(null)
  const [e, setE] = useState('')

  useEffect(() => {
    api.get('/admin/master-report')
      .then(x => setR(x.data.data))
      .catch(x => setE(x.response?.data?.message || x.message))
  }, [])

  const dl = () => {
    const lines = Object.entries(r).flatMap(([t, a]) =>
      a.map(x => `${t},${x.id},${x.bus_number || x.route_number || x.stop_name || x.shift_name || x.vendor_name || x.driver_name || x.conductor_name || ''},${x.status || ''}`)
    )
    const u = URL.createObjectURL(new Blob([`Type,ID,Name,Status\n${lines.join('\n')}`], { type: 'text/csv' }))
    const a = document.createElement('a')
    a.href = u
    a.download = 'bus-master-report.csv'
    a.click()
    URL.revokeObjectURL(u)
  }

  return (
    <div className="stack master-report-page">
      <div className="page-header">
        <div>
          <h1>Master report</h1>
          <p className="page-subtitle">Consolidated overview of all system master data.</p>
        </div>
        {r && (
          <Button onClick={dl} className="btn-download">
            <svg className="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" width="20" height="20">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
            </svg>
            Download CSV
          </Button>
        )}
      </div>

      {e && <Notice tone="danger">{e}</Notice>}

      {r ? (
        Object.entries(r).map(([key, rows]) => {
          const config = TABLE_CONFIG[key]
          if (!config) return null

          return (
            <div className="card" key={key}>
              <h2>{config.label}</h2>
              <div className="admin-master-table">
                <table>
                  <thead>
                    <tr>
                      {config.columns.map((col) => (
                        <th key={col.key}>{col.label}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, idx) => (
                      <tr key={row.id || idx}>
                        {config.columns.map((col) => (
                          <td key={col.key}>
                            {col.type === 'status'
                              ? <StatusBadge status={config.getValue(row, col.key)} size="sm" />
                              : config.getValue(row, col.key)}
                          </td>
                        ))}
                      </tr>
                    ))}
                    {!rows.length && (
                      <tr>
                        <td colSpan={config.columns.length} className="admin-master-empty">
                          No records found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )
        })
      ) : (
        <div className="card">
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Preparing report…</p>
          </div>
        </div>
      )}
    </div>
  )
}
