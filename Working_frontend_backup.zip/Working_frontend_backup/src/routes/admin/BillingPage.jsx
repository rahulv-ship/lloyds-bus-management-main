import { useEffect, useCallback, useState } from 'react'
import api from '../../services/api'
import Notice from '../../components/common/Notice'
import Button from '../../components/common/Button'
import { Trash2, Pencil } from 'lucide-react'
import './BillingPage.css'

const CONFIG = {
  billing: ['month', 'bus', 'route', 'trips', 'amount', 'status'],
}

const label = (x) =>
  x
    .replaceAll('_', ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())

const emptyForm = (fields) => {
  const form = {}
  fields.forEach((f) => {
    form[f] = ''
  })
  return form
}

export default function BillingPage() {
  const [entity] = useState('billing')
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({})
  const [editingId, setEditingId] = useState(null)
  const [notice, setNotice] = useState('')

  const fields = CONFIG[entity] || []

  const load = useCallback(() => {
    setNotice('')
    api
      .get('/admin/billing')
      .then((r) => setRows(Array.isArray(r.data?.data) ? r.data.data : []))
      .catch((e) => {
        setRows([])
        setNotice(e.response?.data?.message || e.message)
      })
  }, [entity])

  useEffect(() => {
    load()
  }, [load])

  const startEdit = (row) => {
    setEditingId(row.id)
    const next = {}
    fields.forEach((f) => {
      next[f] = row[f] ?? ''
    })
    setForm(next)
  }

  const cancelEdit = () => {
    setEditingId(null)
    setForm(emptyForm(fields))
  }

  const save = async (e) => {
    e.preventDefault()
    const isEdit = editingId !== null
    const payload = { ...form }

    try {
      if (isEdit) {
        await api.put(`/admin/billing/${editingId}`, payload)
        setNotice('Billing record updated.')
        setEditingId(null)
      } else {
        await api.post(`/admin/billing`, payload)
        setNotice('Billing record added.')
      }
      setForm(emptyForm(fields))
      load()
    } catch (err) {
      setNotice(err.response?.data?.message || err.message)
    }
  }

  const remove = async (row) => {
    if (!window.confirm(`Delete this billing record? This cannot be undone.`)) return
    try {
      await api.delete(`/admin/billing/${row.id}`)
      setNotice('Billing record deleted.')
      if (editingId === row.id) {
        setEditingId(null)
        setForm(emptyForm(fields))
      }
      load()
    } catch (err) {
      setNotice(err.response?.data?.message || err.message)
    }
  }

  const isEditMode = editingId !== null

  return (
    <div className="stack">
      <div>
        <h1>Billing management</h1>
        <p>Trip billing, usage-based charges, and payment status.</p>
      </div>

      {notice && <Notice>{notice}</Notice>}

      <div className="card">
        <form className="admin-master-form" onSubmit={save}>
          {fields.map((f) => (
            <label className="field" key={f}>
              <span className="field__label">{label(f)}</span>
              {f === 'status' ? (
                <select
                  value={form[f] || 'PENDING'}
                  onChange={(e) => setForm({ ...form, [f]: e.target.value })}
                >
                  <option>PENDING</option>
                  <option>PAID</option>
                  <option>FAILED</option>
                </select>
              ) : f === 'amount' || f === 'trips' ? (
                <input
                  type="number"
                  value={form[f] || ''}
                  onChange={(e) => setForm({ ...form, [f]: e.target.value })}
                />
              ) : (
                <input
                  value={form[f] || ''}
                  onChange={(e) => setForm({ ...form, [f]: e.target.value })}
                />
              )}
            </label>
          ))}
          <div className="admin-master-form__actions">
            <Button type="submit">{isEditMode ? 'Update record' : 'Add record'}</Button>
            {isEditMode && (
              <Button type="button" variant="ghost" onClick={cancelEdit}>
                Cancel
              </Button>
            )}
          </div>
        </form>
      </div>

      <div className="card">
        <h2>Billing records</h2>
        <div className="admin-master-table">
          <table>
            <thead>
              <tr>
                {fields.map((f) => (
                  <th key={f}>{label(f)}</th>
                ))}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  {fields.map((f) => (
                    <td key={f}>{row[f] ?? '—'}</td>
                  ))}
                  <td>
                    <div className="admin-master-actions">
                      <button
                        type="button"
                        className="admin-master-edit"
                        onClick={() => startEdit(row)}
                      >
                        <Pencil size={15} />
                        Edit
                      </button>
                      <button
                        type="button"
                        className="admin-master-delete"
                        onClick={() => remove(row)}
                      >
                        <Trash2 size={15} />
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {!rows.length && (
                <tr>
                  <td colSpan={fields.length + 1} className="admin-master-empty">
                    No billing records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
