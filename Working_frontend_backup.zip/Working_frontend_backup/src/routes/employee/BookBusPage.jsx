import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  MapPin, Route, CalendarDays, Bus, Clock, UserRound, CheckCircle2, ArrowRight, ChevronLeft, ChevronRight as ChevronRightIcon,
} from 'lucide-react'
import { useBookingForm } from '../../hooks/useBookingForm'
import { useSessionContext } from '../../hooks/SessionContext'
import { formatTime, getDateLabel } from '../../utils/format'
import Button from '../../components/common/Button'
import AlertModal from '../../components/common/AlertModal'
import Modal from '../../components/common/Modal'
import './BookBusPage.css'

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

export default function BookBusPage() {
  const navigate = useNavigate()
  const booking = useBookingForm({})
  const { session } = useSessionContext()
  const employee = session?.user || {}

  const [step, setStep] = useState(1)
  const [alert, setAlert] = useState('')
  const [showSuccess, setShowSuccess] = useState(false)
  const [currentMonth, setCurrentMonth] = useState(booking.calendarMonth)

  useEffect(() => {
    if (booking.notice) setAlert(booking.notice)
  }, [booking.notice])

  useEffect(() => {
    setCurrentMonth(booking.calendarMonth)
  }, [booking.calendarMonth])

  const readyForBuses = Boolean(
    booking.form.source &&
    booking.form.pickup_stop_id &&
    booking.form.shift_id &&
    booking.form.booking_dates.length
  )

  const handleNext = () => {
    if (step === 1) {
      if (!booking.form.source || !booking.form.pickup_stop_id || !booking.form.shift_id) {
        setAlert('Please complete all journey details before continuing.')
        return
      }
      if (!booking.form.booking_dates.length) {
        setAlert('Please select at least one travel date.')
        return
      }
      setStep(2)
      return
    }
    if (step === 2) {
      if (!booking.form.bus_id) {
        setAlert('Please select a bus to continue.')
        return
      }
      setStep(3)
    }
  }

  const handleBack = () => {
    if (step > 1) setStep(step - 1)
  }

  const handleSubmit = async () => {
    const success = await booking.submit()
    if (success) {
      setShowSuccess(true)
    }
  }

  const handleCloseSuccess = () => {
    setShowSuccess(false)
    navigate('/app/bookings')
  }

  const handleMonthChange = (delta) => {
    booking.changeCalendarMonth(delta)
  }

  const selectedBus = booking.buses.find((b) => String(b.bus_id) === String(booking.form.bus_id))

  const sourceLabel = booking.sources.find((s) => s.key === booking.form.source)?.label || ''
  const boardingLabel = booking.boardingPoints.find((p) => p.stop_id === booking.form.pickup_stop_id)?.stop_name || ''

  const [year, month] = currentMonth.split('-').map(Number)
  const firstDayOffset = new Date(year, month - 1, 1).getDay()
  const monthLabel = new Date(`${currentMonth}-01T00:00:00`).toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  })

  return (
    <div className="bookbus-page">
      <div className="bookbus-hero">
        <div className="bookbus-hero__content">
          <span className="bookbus-hero__eyebrow">Employee transport</span>
          <h1>Book your bus pass</h1>
          <p>Select your route, travel dates and preferred bus to generate your bus pass.</p>
        </div>
        <div className="bookbus-hero__icon">
          <Bus size={28} />
        </div>
      </div>

      <div className="bookbus-stepper">
        {[
          { num: 1, title: 'Journey setup', desc: 'Source, boarding stop, shift & dates' },
          { num: 2, title: 'Bus selection', desc: 'Live availability' },
          { num: 3, title: 'Confirm & submit', desc: 'Review your booking' },
        ].map((s, idx) => (
          <div key={s.num} className={`bookbus-step ${step >= s.num ? 'is-active' : ''}`}>
            <div className="bookbus-step__dot">{step > s.num ? <CheckCircle2 size={16} /> : s.num}</div>
            <div className="bookbus-step__text">
              <div className="bookbus-step__title">{s.title}</div>
              <div className="bookbus-step__desc">{s.desc}</div>
            </div>
            {idx < 2 && <div className="bookbus-step__line" />}
          </div>
        ))}
      </div>

      {alert && (
        <AlertModal
          open={Boolean(alert)}
          title="Notice"
          message={alert}
          confirmLabel="Close"
          onConfirm={() => {
            setAlert('')
            booking.setNotice('')
          }}
        />
      )}

      <div className="bookbus-card">
        {step === 1 && (
          <div className="bookbus-section">
            <div className="bookbus-section__header">
              <div className="bookbus-section__title">
                <Route size={18} />
                <h2>Journey details</h2>
              </div>
              <p>Choose your source, boarding point and shift</p>
            </div>

            <div className="bookbus-identity">
              <UserRound size={18} />
              <div>
                <span>Booking for</span>
                <b>{employee.name || employee.employee_name || 'Employee'} · {employee.employeeId || employee.employee_id || '—'}</b>
              </div>
              <small>{employee.department || 'Department unavailable'}</small>
            </div>

            <div className="bookbus-grid">
              <label className="bookbus-field">
                <span><Route size={16} /> Source</span>
                <select value={booking.form.source} onChange={(e) => booking.setSource(e.target.value)}>
                  <option value="">Select source</option>
                  {booking.sources.map((src) => (
                    <option key={src.key} value={src.key}>{src.label}</option>
                  ))}
                </select>
              </label>

              <label className="bookbus-field">
                <span><MapPin size={16} /> Boarding stop</span>
                <select
                  value={booking.form.pickup_stop_id}
                  disabled={!booking.form.source || booking.loadingBoarding}
                  onChange={(e) => booking.setBoardingPoint(e.target.value)}
                >
                  <option value="">{booking.loadingBoarding ? 'Loading stops...' : 'Select boarding stop'}</option>
                  {booking.boardingPoints.map((pt) => (
                    <option key={pt.stop_id} value={pt.stop_id}>{pt.stop_name}</option>
                  ))}
                </select>
              </label>

              <label className="bookbus-field">
                <span><Clock size={16} /> Shift</span>
                <select value={booking.form.shift_id} onChange={(e) => booking.setShift(e.target.value)}>
                  <option value="">Select shift</option>
                  {booking.shifts.map((sh) => (
                    <option key={sh.id} value={sh.id}>{sh.shift_name}{sh.start_time && sh.end_time ? ` · ${formatTime(sh.start_time)}–${formatTime(sh.end_time)}` : ''}</option>
                  ))}
                </select>
              </label>

              <label className="bookbus-field">
                <span><CalendarDays size={16} /> Weekly off</span>
                <select value={booking.form.weekoff_day} onChange={(e) => booking.setWeekoffDay(e.target.value)}>
                  <option value="">No weekly off selected</option>
                  <option value="0">Sunday</option>
                  <option value="1">Monday</option>
                  <option value="2">Tuesday</option>
                  <option value="3">Wednesday</option>
                  <option value="4">Thursday</option>
                  <option value="5">Friday</option>
                  <option value="6">Saturday</option>
                </select>
                <small>Weekly-off dates are locked as holidays.</small>
              </label>
            </div>

            <div className="bookbus-calendar">
              <div className="bookbus-section__title">
                <CalendarDays size={18} />
                <h2>Travel dates</h2>
              </div>
              <p>Select one or more days for your bus pass</p>

              <div className="bookbus-calendar__nav">
                <button type="button" onClick={() => handleMonthChange(-1)} aria-label="Previous month">
                  <ChevronLeft size={18} />
                </button>
                <span>{monthLabel}</span>
                <button type="button" onClick={() => handleMonthChange(1)} aria-label="Next month">
                  <ChevronRightIcon size={18} />
                </button>
              </div>

              <div className="bookbus-calendar__weekdays">
                {WEEKDAYS.map((d) => <span key={d}>{d}</span>)}
              </div>

              <div className="bookbus-calendar__grid">
                {Array.from({ length: firstDayOffset }).map((_, i) => <span key={`b-${i}`} />)}
                {booking.monthDates.map((date) => {
                  const isPast = date < booking.today
                  const isToday = date === booking.today
                  const selected = booking.isDateSelected(date)
                  const isWeekoff = String(new Date(`${date}T00:00:00`).getDay()) === String(booking.form.weekoff_day)
                  return (
                    <button
                      type="button"
                      key={date}
                      disabled={isPast || isWeekoff}
                      onClick={() => booking.toggleDate(date)}
                      className={`bookbus-calendar__day ${selected ? 'is-selected' : ''} ${isToday ? 'is-today' : ''} ${isPast ? 'is-past' : ''} ${isWeekoff ? 'is-weekoff' : ''}`}
                    >
                      {new Date(date).getDate()}
                    </button>
                  )
                })}
              </div>

              <div className="bookbus-calendar__actions">
                <Button variant="ghost" size="sm" onClick={booking.selectWholeMonth} disabled={!booking.selectableMonthDates.length}>This month</Button>
                <Button variant="ghost" size="sm" onClick={booking.selectNext15Days} disabled={!booking.selectableMonthDates.length}>Next 15 days</Button>
                <Button variant="ghost" size="sm" onClick={booking.selectNext30Days} disabled={!booking.selectableMonthDates.length}>Next 30 days</Button>
                <Button variant="ghost" size="sm" onClick={booking.clearDates} disabled={!booking.form.booking_dates.length}>Clear</Button>
              </div>

              <div className="bookbus-calendar__summary">
                <b>{booking.form.booking_dates.length}</b> travel {booking.form.booking_dates.length === 1 ? 'day' : 'days'} selected
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="bookbus-section">
            <div className="bookbus-section__header">
              <div className="bookbus-section__title">
                <Bus size={18} />
                <h2>Choose an available bus</h2>
              </div>
              <p>{readyForBuses ? 'Select the bus for your route' : 'Complete journey details to see buses'}</p>
            </div>

            {!readyForBuses && <div className="bookbus-empty">Please complete step 1 to view available buses.</div>}
            {readyForBuses && booking.loadingBuses && <div className="bookbus-empty">Loading available buses...</div>}
            {readyForBuses && !booking.loadingBuses && !booking.buses.length && (
              <div className="bookbus-empty">No buses available for selected boarding point, shift and dates.</div>
            )}

            {readyForBuses && !booking.loadingBuses && booking.buses.length > 0 && (
              <div className="bookbus-bus-grid">
                {booking.buses.map((bus) => {
                  const isSelected = String(booking.form.bus_id) === String(bus.bus_id)
                  const capacity = bus.capacity || 52
                  return (
                    <div key={`${bus.bus_id}-${bus.bus_route_id}`} className={`bookbus-bus-card ${isSelected ? 'is-selected' : ''} ${!bus.available ? 'is-unavailable' : ''}`}>
                      <div className="bookbus-bus-card__head">
                        <div>
                          <div className="bookbus-bus-card__num">{bus.bus_number}</div>
                          <div className="bookbus-bus-card__route">{bus.route_number} · {bus.route_name}</div>
                        </div>
                        <div className="bookbus-bus-card__cap">{bus.remaining_capacity}/{capacity} seats left</div>
                      </div>
                      <div className="bookbus-bus-card__meta">
                        <div><MapPin size={14} /> {bus.pickup_stop_name}</div>
                        <div><Clock size={14} /> {formatTime(bus.onboarding_time)} boarding</div>
                        <div><ArrowRight size={14} /> {bus.drop_stop_name || 'Plant'}</div>
                      </div>
                      {bus.date_wise_capacity?.length > 0 && (
                        <div className="bookbus-bus-card__dates">
                          {bus.date_wise_capacity.slice(0, 6).map((d) => (
                            <div key={d.date} className={`bookbus-bus-card__date ${!d.available ? 'full' : ''}`}>
                              <span>{getDateLabel(d.date)}</span>
                              <span>{d.available ? `${d.remaining}/${d.capacity}` : 'Full'}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <Button
                        variant={isSelected ? 'primary' : 'secondary'}
                        size="md"
                        fullWidth
                        disabled={!bus.available}
                        onClick={() => booking.selectBus(bus)}
                      >
                        {isSelected ? 'Selected' : bus.available ? 'Select this bus' : 'Not available'}
                      </Button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="bookbus-section">
            <div className="bookbus-section__header">
              <div className="bookbus-section__title">
                <CheckCircle2 size={18} />
                <h2>Review & confirm</h2>
              </div>
              <p>Verify your journey details before generating the pass</p>
            </div>

            <div className="bookbus-review">
              <div className="bookbus-review__route">
                <div>{sourceLabel || '—'}</div>
                <ArrowRight size={18} />
                <div>Plant</div>
              </div>

              <div className="bookbus-review__grid">
                <div className="bookbus-review__item">
                  <MapPin size={16} />
                  <div>
                    <span>Boarding point</span>
                    <b>{boardingLabel || '—'}</b>
                  </div>
                </div>
                <div className="bookbus-review__item">
                  <Clock size={16} />
                  <div>
                    <span>Shift</span>
                    <b>{booking.shifts.find((sh) => String(sh.id) === String(booking.form.shift_id))?.shift_name || '—'}</b>
                  </div>
                </div>
                <div className="bookbus-review__item">
                  <Route size={16} />
                  <div>
                    <span>Route</span>
                    <b>{selectedBus ? `${selectedBus.route_number} · ${selectedBus.route_name}` : '—'}</b>
                  </div>
                </div>
                <div className="bookbus-review__item">
                  <Bus size={16} />
                  <div>
                    <span>Bus</span>
                    <b>{selectedBus?.bus_number || '—'}</b>
                  </div>
                </div>
                <div className="bookbus-review__item">
                  <Clock size={16} />
                  <div>
                    <span>Boarding time</span>
                    <b>{selectedBus ? formatTime(selectedBus.onboarding_time) : '—'}</b>
                  </div>
                </div>
                <div className="bookbus-review__item">
                  <CalendarDays size={16} />
                  <div>
                    <span>Travel days</span>
                    <b>{booking.form.booking_dates.length} {booking.form.booking_dates.length === 1 ? 'day' : 'days'}</b>
                  </div>
                </div>
              </div>

              <div className="bookbus-review__dates">
                {booking.form.booking_dates.map((d) => (
                  <span key={d} className="bookbus-review__date-chip">{getDateLabel(d)}</span>
                ))}
              </div>

              {booking.form.booking_dates.length > 0 && (
                <div className="bookbus-review__validity">
                  Valid from {getDateLabel(booking.form.booking_dates[0])} to {getDateLabel(booking.form.booking_dates[booking.form.booking_dates.length - 1])}
                </div>
              )}
            </div>
          </div>
        )}

        <div className="bookbus-actions">
          <div>
            {step > 1 && (
              <Button variant="secondary" onClick={handleBack} icon={ChevronLeft}>Back</Button>
            )}
          </div>
          <div className="bookbus-actions__right">
            {step < 3 && <Button variant="primary" onClick={handleNext} icon={ChevronRightIcon} iconPosition="right">Continue</Button>}
            {step === 3 && <Button variant="primary" loading={booking.loading} onClick={handleSubmit}>Generate bus pass</Button>}
          </div>
        </div>
      </div>

      <Modal
        open={showSuccess}
        title="Bus pass generated"
        message="Your bus pass application has been submitted successfully. It will appear in My Pass once approved."
        confirmLabel="Go to My Bookings"
        onConfirm={handleCloseSuccess}
      />
    </div>
  )
}
