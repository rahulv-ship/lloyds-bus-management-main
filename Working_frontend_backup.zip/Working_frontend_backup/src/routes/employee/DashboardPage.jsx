import React, { useState, useEffect, useRef } from 'react'
import {
  QrCode, Bell, Armchair, Calendar, MapPin, Headset, User, LogOut,
  Bus, Clock, Flag, Users, IdCard, CircleUser, X, ChevronRight, ChevronLeft,
  Phone, Mail, CircleCheck, TriangleAlert, Map, CalendarDays, Navigation,
  RefreshCw, Route as RouteIcon,
} from 'lucide-react'
import { useApplications } from '../../hooks/useApplications'
import { useSessionContext } from '../../hooks/SessionContext'
import GpsDashboard from '../../components/gps/GpsDashboard'
import DigitalPassCard from '../../components/pass/DigitalPassCard'
import { fetchBusTiming } from '../../services/busTimingService'
import { submitSupportTicket } from '../../services/supportService'
import api from '../../services/api'
import busViewImg from './Bus_view.png'
import './DashboardPage.css'

// ============================================================
// SAMPLE TIMINGS
// ============================================================
const SAMPLE_TIMINGS = [
  {
    id: 'sample-1', time: '07:30 AM', period: 'Pickup',
    fromLocation: 'Lloyds Colony', fromSub: 'Boarding Point 1',
    toLocation: 'Steel Plant Main Gate', toSub: 'Plant Entry',
    busNumber: 'MH 34 AB 1234', route: 'R-01', driver: 'Rahul Verma',
    capacity: 52, available: 14, status: 'On Time',
    shiftTime: '07:00 AM - 03:00 PM', shiftName: 'General Shift',
    estimatedArrival: '07:50 AM', journeyDuration: '20m',
  },
  {
    id: 'sample-2', time: '08:15 AM', period: 'Pickup',
    fromLocation: 'Lloyds Colony', fromSub: 'Boarding Point 2',
    toLocation: 'Steel Plant Main Gate', toSub: 'Plant Entry',
    busNumber: 'MH 34 AB 5678', route: 'R-02', driver: 'Suresh Patil',
    capacity: 45, available: 8, status: 'On Time',
    shiftTime: '08:00 AM - 04:00 PM', shiftName: 'Shift A',
    estimatedArrival: '08:40 AM', journeyDuration: '25m',
  },
  {
    id: 'sample-3', time: '04:30 PM', period: 'Drop',
    fromLocation: 'Steel Plant Main Gate', fromSub: 'Plant Exit',
    toLocation: 'Lloyds Colony', toSub: 'Drop Point 1',
    busNumber: 'MH 34 AB 1234', route: 'R-01', driver: 'Rahul Verma',
    capacity: 52, available: 20, status: 'Delayed',
    shiftTime: '07:00 AM - 03:00 PM', shiftName: 'General Shift',
    estimatedArrival: '04:55 PM', journeyDuration: '25m',
  },
  {
    id: 'sample-4', time: '05:00 PM', period: 'Drop',
    fromLocation: 'Steel Plant Main Gate', fromSub: 'Plant Exit',
    toLocation: 'Lloyds Colony', toSub: 'Drop Point 2',
    busNumber: 'MH 34 AB 9012', route: 'R-03', driver: 'Amit Joshi',
    capacity: 50, available: 32, status: 'On Time',
    shiftTime: '09:00 AM - 05:00 PM', shiftName: 'Shift B',
    estimatedArrival: '05:30 PM', journeyDuration: '30m',
  },
]

function useIsMobile(breakpoint = 900) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== 'undefined' ? window.innerWidth <= breakpoint : false
  )
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= breakpoint)
    window.addEventListener('resize', handleResize)
    handleResize()
    return () => window.removeEventListener('resize', handleResize)
  }, [breakpoint])
  return isMobile
}

const STEP = {
  SOURCE: 1,
  BOARDING_STOP: 2,
  SHIFT: 3,
  DATES: 4,
  BUS: 5,
  CONFIRM: 6,
}

export default function DashboardPage() {
  const isMobile = useIsMobile(900)
  const { logout, session } = useSessionContext()
  const { approved } = useApplications()

  const [activeTab, setActiveTab] = useState('Home')
  const [showProfileDropdown, setShowProfileDropdown] = useState(false)
  const [selectedSchedule, setSelectedSchedule] = useState(null)
  const [toast, setToast] = useState({ show: false, message: '' })
  const [modal, setModal] = useState(null)
  const [mapEndpoints, setMapEndpoints] = useState({
    start: 'Lloyds Colony',
    end: 'Steel Plant Main Gate',
  })
  const [scheduleFilter, setScheduleFilter] = useState('all')
  const [scheduleTimings, setScheduleTimings] = useState(SAMPLE_TIMINGS)
  const [scheduleLoading, setScheduleLoading] = useState(true)
  const [scheduleError, setScheduleError] = useState(null)
  const [rightMenuOpen, setRightMenuOpen] = useState(false)
  const [gpsVehicles, setGpsVehicles] = useState([])
  const [gpsLoading, setGpsLoading] = useState(false)
  const [gpsError, setGpsError] = useState(null)
  const [myBookings, setMyBookings] = useState([])
  const [bookingsLoading, setBookingsLoading] = useState(false)
  const [supportSubmitting, setSupportSubmitting] = useState(false)
  const [supportSubmitted, setSupportSubmitted] = useState(false)
  const [supportSubject, setSupportSubject] = useState('')
  const [supportMessage, setSupportMessage] = useState('')

  // Booking flow
  const [bookStep, setBookStep] = useState(STEP.SOURCE)
  const [routes, setRoutes] = useState([])
  const [boardingStops, setBoardingStops] = useState([])
  const [shifts, setShifts] = useState([])
  const [buses, setBuses] = useState([])
  const [selectedSource, setSelectedSource] = useState(null)
  const [selectedBoardingStop, setSelectedBoardingStop] = useState(null)
  const [selectedShift, setSelectedShift] = useState(null)
  const [selectedBus, setSelectedBus] = useState(null)
  const [bookingDates, setBookingDates] = useState([])
  const [passValidFrom, setPassValidFrom] = useState('')
  const [passValidTo, setPassValidTo] = useState('')
  const [shiftStartTime, setShiftStartTime] = useState('')
  const [shiftEndTime, setShiftEndTime] = useState('')
  const [bookingLoading, setBookingLoading] = useState(false)
  const [routesLoading, setRoutesLoading] = useState(false)
  const [shiftsLoading, setShiftsLoading] = useState(false)
  const [busesLoading, setBusesLoading] = useState(false)
  const [boardingStopsLoading, setBoardingStopsLoading] = useState(false)
  const [travelDaysCount, setTravelDaysCount] = useState(30)

  const profileBtnRef = useRef(null)
  const menuBtnRef = useRef(null)

  const showToast = (message) => {
    setToast({ show: true, message })
    setTimeout(() => setToast({ show: false, message: '' }), 2500)
  }

  // Close dropdowns on outside click
  useEffect(() => {
    const onClick = (event) => {
      if (profileBtnRef.current && !profileBtnRef.current.contains(event.target)) {
        setShowProfileDropdown(false)
      }
      if (menuBtnRef.current && !menuBtnRef.current.contains(event.target)) {
        setRightMenuOpen(false)
      }
    }
    document.addEventListener('click', onClick)
    return () => document.removeEventListener('click', onClick)
  }, [])

  // Load timings
  useEffect(() => {
    const loadTimings = async () => {
      setScheduleLoading(true)
      setScheduleError(null)
      try {
        const data = await fetchBusTiming()
        const timings = (data && data.timings) || []
        setScheduleTimings(timings.length > 0 ? timings : SAMPLE_TIMINGS)
      } catch (error) {
        setScheduleError(error.message || 'Using sample timings')
        setScheduleTimings(SAMPLE_TIMINGS)
      } finally {
        setScheduleLoading(false)
      }
    }
    loadTimings()
  }, [])

  // ============================================================
  // API loaders
  // ============================================================
  const loadRoutes = async () => {
    setRoutesLoading(true)
    try {
      const res = await api.get('/master/routes')
      const data = res.data?.data || res.data || []
      setRoutes(Array.isArray(data) ? data : [])
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to load routes')
    } finally {
      setRoutesLoading(false)
    }
  }

  const loadBoardingStops = async (sourceId) => {
    setBoardingStopsLoading(true)
    try {
      const res = await api.get(`/master/boarding-points?source=${sourceId}`)
      const data = res.data?.data || res.data || []
      setBoardingStops(Array.isArray(data) ? data : [])
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to load boarding stops')
    } finally {
      setBoardingStopsLoading(false)
    }
  }

  const loadAvailableBuses = async (sourceId, boardingStopId, shiftId, dates) => {
    setBusesLoading(true)
    try {
      const params = new URLSearchParams()
      if (sourceId) params.append('source', sourceId)
      if (boardingStopId) params.append('pickup_stop_id', boardingStopId)
      if (shiftId) params.append('shift_id', shiftId)
      if (dates && dates.length > 0) params.append('booking_dates', dates.join(','))
      const res = await api.get(`/master/available-buses?${params.toString()}`)
      const data = res.data?.data?.buses || res.data?.buses || res.data?.data || []
      setBuses(Array.isArray(data) ? data : [])
      setSelectedBus(null)
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to load buses')
    } finally {
      setBusesLoading(false)
    }
  }

  const loadShifts = async () => {
    setShiftsLoading(true)
    try {
      const res = await api.get('/master/shifts')
      const data = res.data?.data || res.data || []
      setShifts(Array.isArray(data) ? data : [])
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to load shifts')
    } finally {
      setShiftsLoading(false)
    }
  }

  const resetBookingState = () => {
    setBookStep(STEP.SOURCE)
    setSelectedSource(null)
    setSelectedBoardingStop(null)
    setSelectedShift(null)
    setSelectedBus(null)
    setBookingDates([])
    setPassValidFrom('')
    setPassValidTo('')
    setShiftStartTime('')
    setShiftEndTime('')
    setTravelDaysCount(30)
    setRoutes([])
    setBoardingStops([])
    setShifts([])
    setBuses([])
  }

  const openBookBus = async () => {
    resetBookingState()
    setModal('booking')
    await Promise.all([loadRoutes(), loadShifts()])
  }

  // Generate dates: handles 15, 30, or 'month'
  const generateBookingDates = () => {
    const dates = []
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    let limit
    if (travelDaysCount === 'month') {
      const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0)
      limit = lastDay.getDate() - today.getDate() + 1
    } else {
      limit = Number(travelDaysCount) || 30
    }

    const currentDate = new Date(today)
    for (let i = 0; i < limit; i++) {
      dates.push(currentDate.toISOString().split('T')[0])
      currentDate.setDate(currentDate.getDate() + 1)
    }
    return dates
  }

  // ============================================================
  // MY BOOKINGS
  // ============================================================
  const loadMyBookings = async () => {
    setBookingsLoading(true)
    setMyBookings([])
    try {
      const res = await api.get('/bus-pass/my-applications')
      const list = res?.data?.applications || res?.data?.data || res?.data || []
      setMyBookings(Array.isArray(list) ? list : [])
    } catch (error) {
      setMyBookings([])
      showToast(error.response?.data?.message || 'Failed to load bookings')
    } finally {
      setBookingsLoading(false)
    }
  }

  const openMyBookings = () => {
    setModal('myBookings')
    loadMyBookings()
  }

  // Reload buses whenever booking dates change (with source, stop, shift set)
  useEffect(() => {
    if (selectedSource && selectedBoardingStop && selectedShift && bookingDates.length > 0) {
      loadAvailableBuses(
        selectedSource?.source || selectedSource?.source_name || selectedSource?.name,
        selectedBoardingStop?.stop_id || selectedBoardingStop?.id,
        selectedShift?.id,
        bookingDates
      )
    }
  }, [bookingDates])

  // ============================================================
  // Handlers
  // ============================================================
  const handleTabClick = (tab) => {
    setActiveTab(tab)
    if (tab === 'My Pass') setModal('qr')
    else if (tab === 'Profile') setModal('profile')
    else setModal(null)
  }

  const handleToggleProfile = (e) => {
    e.stopPropagation()
    setShowProfileDropdown((v) => !v)
  }

  const handleToggleMenu = (e) => {
    e.stopPropagation()
    setRightMenuOpen((v) => !v)
  }

  const handleLogout = () => {
    setShowProfileDropdown(false)
    setRightMenuOpen(false)
    if (window.confirm('Are you sure you want to logout?')) {
      logout()
      showToast('Logged out successfully')
    }
  }

  const filteredSchedule = scheduleTimings.filter((item) => {
    if (scheduleFilter === 'all') return true
    if (scheduleFilter === 'pickup') return item.period === 'Pickup'
    if (scheduleFilter === 'drop') return item.period === 'Drop'
    if (scheduleFilter === 'delayed') return item.status === 'Delayed'
    return true
  })

  const userInitials = (session?.user?.name || session?.user?.employee_name || 'E')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  const fullName = session?.user?.name || session?.user?.employee_name || 'Employee'
  const employeeId = session?.user?.employeeId || session?.user?.employee_id || 'EMP001'

  const handleSelectSchedule = (id) => {
    setSelectedSchedule(id)
    const item = scheduleTimings.find((s) => s.id === id)
    if (item) showToast(`Selected: ${item.time} from ${item.fromLocation}`)
  }

  const openGpsDashboard = async () => {
    setGpsError(null)
    setGpsLoading(true)
    setModal('gps')
    try {
      const res = await api.get('/vehicles')
      const body = res?.data
      const list = body?.data?.list || body?.data || body?.list || []
      setGpsVehicles(Array.isArray(list) ? list : [])
    } catch (error) {
      setGpsError(
        error.response?.data?.message ||
          error.message ||
          'Could not reach GPS service. Is the backend running on port 5000?'
      )
      setGpsVehicles([])
    } finally {
      setGpsLoading(false)
    }
  }

  const closeModal = () => setModal(null)

  const handleQuickAction = async (action) => {
    setRightMenuOpen(false)
    switch (action) {
      case 'bookSeat':
        await openBookBus()
        break
      case 'myBookings':
        openMyBookings()
        break
      case 'trackBus':
        openGpsDashboard()
        break
      case 'support':
        setModal('support')
        setSupportSubmitted(false)
        break
      default:
        break
    }
  }

  const handleSubmitBooking = async () => {
    if (!selectedBus || !selectedSource || !selectedBoardingStop || !selectedShift || bookingDates.length === 0) {
      showToast('Please complete all booking steps before submitting')
      return
    }
    setBookingLoading(true)
    try {
      await api.post('/bus-pass/applications', {
        route_id: selectedBus?.route_id || selectedSource?.id,
        shift_id: selectedBus?.shift_id || selectedShift?.id,
        bus_id: selectedBus?.bus_id,
        pickup_stop_id: selectedBus?.pickup_stop_id || selectedBoardingStop?.stop_id || selectedBoardingStop?.id,
        drop_stop_id: selectedBus?.drop_stop_id,
        booking_dates: bookingDates,
        pass_valid_from: passValidFrom || bookingDates[0],
        pass_valid_to: passValidTo || bookingDates[bookingDates.length - 1],
      })
      closeModal()
      resetBookingState()
      showToast('Bus pass application submitted successfully! It will be reviewed by admin.')
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to submit application')
    } finally {
      setBookingLoading(false)
    }
  }

  // ============================================================
  // Styles
  // ============================================================
  const actionBtnStyle = {
    display: 'flex',
    flexDirection: isMobile ? 'row' : 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    padding: isMobile ? '10px 8px' : '12px 6px',
    border: '1px solid var(--border-color)',
    borderRadius: '10px',
    background: '#fff',
    fontSize: isMobile ? '11px' : '10px',
    fontWeight: 600,
    gap: '6px',
    margin: 0,
    boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    cursor: 'pointer',
    color: 'var(--text-dark)',
    fontFamily: 'inherit',
    transition: 'all 0.2s ease',
    width: '100%',
    flex: isMobile ? '1' : 'unset',
    minWidth: isMobile ? '0' : 'auto',
  }

  const actionIconStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '28px',
    height: '28px',
    borderRadius: '8px',
    background: '#FFF0F0',
    color: '#D32F2F',
    flexShrink: 0,
  }

  const mobileTabStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '2px',
    padding: '6px 4px',
    background: 'transparent',
    border: 'none',
    cursor: 'pointer',
    color: '#757575',
    fontFamily: 'inherit',
    fontSize: '9px',
    fontWeight: 500,
    flex: '0 0 auto',
    minWidth: '56px',
    transition: 'color 0.2s ease',
  }

  const mobileTabIconStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '22px',
    height: '22px',
  }

  // Helper to advance from dates -> bus
  const goToBusStep = async () => {
    if (bookingDates.length === 0) {
      showToast('Please select at least one travel date')
      return
    }
    setBookStep(STEP.BUS)
    await loadAvailableBuses(
      selectedSource?.source || selectedSource?.source_name || selectedSource?.name,
      selectedBoardingStop?.stop_id || selectedBoardingStop?.id,
      selectedShift?.id,
      bookingDates
    )
  }

  return (
    <div className="app-container" style={{ paddingBottom: isMobile ? '90px' : '0' }}>
      {/* TOP BAR */}
      <div className="top-bar" style={{ padding: isMobile ? '10px 14px' : '12px 24px' }}>
        <div className="top-bar-left">
          <div className="logo-image">
            <img
              src="/Logo.png"
              alt="Lloyds Metals Logo"
              style={{ height: isMobile ? '28px' : '36px' }}
              onError={(e) => {
                e.target.style.display = 'none'
                e.target.nextElementSibling.style.display = 'block'
              }}
            />
            <div className="logo-placeholder" style={{ display: 'none' }}>
              LLOYDS METALS <br />
              <span style={{ fontSize: '6px', color: '#aaa' }}>AND ENERGY LIMITED</span>
            </div>
          </div>
        </div>

        <div className="top-bar-right" style={{ gap: isMobile ? '8px' : '16px' }}>
          <div className="top-nav-tabs" style={{ display: isMobile ? 'none' : 'flex' }}>
            <div
              className={`top-nav-item ${activeTab === 'My Pass' ? 'active' : ''}`}
              onClick={() => handleTabClick('My Pass')}
            >
              <QrCode size={16} />
              <span>My Pass</span>
            </div>
          </div>

          <div
            className="notification-icon"
            onClick={() => setModal('notifications')}
            style={{ width: isMobile ? '34px' : '38px', height: isMobile ? '34px' : '38px' }}
          >
            <Bell size={isMobile ? 18 : 20} />
          </div>

          <div
            ref={menuBtnRef}
            className="menu-btn"
            onClick={handleToggleMenu}
            title="Menu"
            style={{ width: isMobile ? '34px' : '38px', height: isMobile ? '34px' : '38px' }}
          >
            ≡
          </div>

          <div
            ref={profileBtnRef}
            className="profile-avatar-btn"
            onClick={handleToggleProfile}
            title="Account"
            style={{
              width: isMobile ? '34px' : '38px',
              height: isMobile ? '34px' : '38px',
              fontSize: isMobile ? '11px' : '13px',
            }}
          >
            {userInitials}
          </div>
        </div>
      </div>

      {/* RIGHT MENU */}
      {rightMenuOpen && (
        <div className="right-menu__overlay" onClick={() => setRightMenuOpen(false)} />
      )}
      <aside className={`right-menu ${rightMenuOpen ? 'right-menu--open' : ''}`}>
        <button
          type="button"
          className="right-menu__close"
          onClick={() => setRightMenuOpen(false)}
          aria-label="Close menu"
        >
          <X size={20} />
        </button>
        <nav className="right-menu__nav">
          <div className="right-menu__section-title">My Assist</div>
          <div className="right-menu__items">
            <button
              className={`right-menu__item ${modal === 'qr' ? 'right-menu__item--active' : ''}`}
              onClick={() => { setRightMenuOpen(false); setModal('qr') }}
            >
              <QrCode size={18} />
              <span>My Bus_QR</span>
            </button>
            <button
              className={`right-menu__item ${modal === 'booking' ? 'right-menu__item--active' : ''}`}
              onClick={async () => { setRightMenuOpen(false); await openBookBus() }}
            >
              <Armchair size={18} />
              <span>Book Bus</span>
            </button>
            <button
              className={`right-menu__item ${modal === 'myBookings' ? 'right-menu__item--active' : ''}`}
              onClick={() => { setRightMenuOpen(false); openMyBookings() }}
            >
              <Bus size={18} />
              <span>My Bookings</span>
            </button>
            <button
              className={`right-menu__item ${modal === 'gps' ? 'right-menu__item--active' : ''}`}
              onClick={() => { setRightMenuOpen(false); openGpsDashboard() }}
            >
              <MapPin size={18} />
              <span>GPS</span>
            </button>
          </div>
          <div className="right-menu__footer">
            <button type="button" className="right-menu__logout" onClick={handleLogout} aria-label="Sign out">
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </nav>
      </aside>

      {/* PROFILE DROPDOWN */}
      {showProfileDropdown && (
        <div
          className="profile-dropdown show"
          style={{ right: isMobile ? '14px' : '24px', width: isMobile ? '220px' : '240px' }}
        >
          <div className="profile-dropdown-header">
            <div className="avatar-sm">{userInitials}</div>
            <div className="user-info">
              <h4>{fullName}</h4>
              <p>{employeeId}</p>
            </div>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setModal('profile'); setShowProfileDropdown(false) }}>
            <User size={16} />
            <span>My Profile</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setShowProfileDropdown(false); openMyBookings() }}>
            <Calendar size={16} />
            <span>My Bookings</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { openGpsDashboard(); setShowProfileDropdown(false) }}>
            <Navigation size={16} />
            <span>GPS Dashboard</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setModal('support'); setShowProfileDropdown(false) }}>
            <Headset size={16} />
            <span>Support</span>
          </div>
          <div className="profile-dropdown-divider"></div>
          <div className="profile-dropdown-item logout" onClick={handleLogout}>
            <LogOut size={16} />
            <span>Logout</span>
          </div>
        </div>
      )}

      {/* MAIN CONTENT */}
      <div className="app-content" style={{ padding: isMobile ? '16px 14px' : '20px 24px' }}>
        <div className="hero" style={{ marginBottom: isMobile ? '18px' : '24px' }}>
          <h1 style={{ fontSize: isMobile ? '22px' : '28px' }}>Employee Transportation</h1>
          <p style={{ fontSize: isMobile ? '13px' : '14px' }}>Safe. Reliable. On time.</p>
        </div>

        <div
          style={{
            display: 'flex',
            flexDirection: isMobile ? 'column' : 'row',
            gap: isMobile ? '14px' : '20px',
            alignItems: 'stretch',
          }}
        >
          <div
            className="main-grid"
            style={{
              flex: 1,
              minWidth: 0,
              display: 'grid',
              gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr',
              gap: isMobile ? '14px' : '20px',
            }}
          >
            {/* LEFT COLUMN */}
            <div className="col-left">
              <div className="section" style={{ padding: 0 }}>
                <h2 className="section-title-dark">My Next Ride</h2>
                <div className="card next-ride-card">
                  <div
                    className="ride-header"
                    style={{
                      flexDirection: isMobile ? 'column' : 'row',
                      alignItems: 'flex-start',
                      gap: isMobile ? '10px' : '0',
                    }}
                  >
                    <div className="bus-info">
                      <div className="bus-icon-box">
                        <Bus size={16} />
                      </div>
                      <div>
                        <h3>Tata Marco Polo Bus</h3>
                        <p>52 Seater</p>
                      </div>
                    </div>
                    <div
                      className="ride-header-right"
                      style={{ gap: isMobile ? '10px' : '26px' }}
                    >
                      <div className="badge-confirmed">Confirmed</div>
                      <button className="gps-icon-btn" onClick={openGpsDashboard} title="Open GPS Dashboard">
                        <MapPin size={13} />
                        <span>GPS</span>
                      </button>
                    </div>
                  </div>
                  <div className="ride-route">
                    <div className="route-line">
                      <div className="dot"></div>
                      <div className="dash"></div>
                      <div className="dot" style={{ background: 'var(--dark-bg)' }}></div>
                    </div>
                    <div className="route-text">
                      <div className="destination-group">
                        <p>Lloyds Colony <span>Start Point</span></p>
                      </div>
                      <div className="destination-group">
                        <p>Steel Plant Main Gate <span>End Destination</span></p>
                      </div>
                    </div>
                  </div>
                  <div className="ride-footer" style={{ gap: isMobile ? '12px' : '16px' }}>
                    <div className="time-box">
                      <Clock size={14} />
                      <div>
                        <p>07:30 AM</p>
                        <p>Pickup Time</p>
                      </div>
                    </div>
                    <div className="time-box">
                      <Flag size={14} />
                      <div>
                        <p>07:50 AM</p>
                        <p>Drop Time</p>
                      </div>
                    </div>
                  </div>
                  <div className="bus-details-section">
                    <img
                      src={busViewImg}
                      alt="Bus Details"
                      className="details-image"
                      style={{ height: isMobile ? '80px' : '100px' }}
                    />
                    <div
                      className="details-footer"
                      style={{ flexDirection: isMobile ? 'column' : 'row', gap: '8px' }}
                    >
                      <div className="detail-item">
                        <Users size={13} />
                        <div>
                          <div>52 Seater</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Tata Marco Polo</div>
                        </div>
                      </div>
                      <div className="detail-item">
                        <IdCard size={13} />
                        <div>
                          <div>MH 34 AB 1234</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Registration No.</div>
                        </div>
                      </div>
                      <div className="detail-item">
                        <CircleUser size={13} />
                        <div>
                          <div>Rahul Verma</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Driver</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT COLUMN */}
            <div className="col-right">
              <div className="section" style={{ padding: 0 }}>
                <h2 className="section-title-dark">Today's Schedule</h2>
                <div className="schedule-full-page">
                  <div
                    className="schedule-header"
                    style={{
                      flexDirection: isMobile ? 'column' : 'row',
                      alignItems: isMobile ? 'stretch' : 'center',
                      gap: isMobile ? '10px' : '0',
                    }}
                  >
                    <h2 className="section-title">Journey Details</h2>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        marginLeft: isMobile ? '0' : 'auto',
                        justifyContent: 'space-between',
                        width: isMobile ? '100%' : 'auto',
                      }}
                    >
                      <select
                        value={scheduleFilter}
                        onChange={(e) => setScheduleFilter(e.target.value)}
                        style={{
                          padding: '6px 10px',
                          border: '1px solid var(--border-color)',
                          borderRadius: '6px',
                          fontSize: isMobile ? '12px' : '11px',
                          background: '#fff',
                          color: 'var(--text-dark)',
                          cursor: 'pointer',
                          outline: 'none',
                          fontFamily: 'inherit',
                          flex: isMobile ? 1 : 'unset',
                        }}
                      >
                        <option value="all">All</option>
                        <option value="pickup">Pickup</option>
                        <option value="drop">Drop</option>
                        <option value="delayed">Delayed</option>
                      </select>
                      <div className="view-all" onClick={() => setModal('fullSchedule')}>
                        View Full <ChevronRight size={12} />
                      </div>
                    </div>
                  </div>

                  {(scheduleLoading || scheduleError) && (
                    <div
                      className="text-muted"
                      style={{
                        fontSize: '11px',
                        marginBottom: '6px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px',
                      }}
                    >
                      {scheduleLoading && <RefreshCw size={11} className="spinning" />}
                      <span>{scheduleLoading ? 'Syncing schedule…' : 'Detail timings'}</span>
                    </div>
                  )}

                  <div style={{ maxHeight: isMobile ? '300px' : '360px', overflowY: 'auto', paddingRight: '4px' }}>
                    {filteredSchedule.map((item) => (
                      <div
                        key={item.id}
                        className="schedule-item"
                        onClick={() => handleSelectSchedule(item.id)}
                        style={{
                          ...(selectedSchedule === item.id
                            ? { backgroundColor: '#fef2f2', borderRadius: '8px', borderLeft: '3px solid var(--primary-red)' }
                            : {}),
                          flexWrap: isMobile ? 'wrap' : 'nowrap',
                          gap: isMobile ? '8px' : '12px',
                        }}
                      >
                        <div className="schedule-time">
                          <div style={{ fontWeight: 800, color: '#0f172a' }}>{item.time}</div>
                          <div style={{ color: '#64748b', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                            {item.period}
                          </div>
                          {item.estimatedArrival && (
                            <div style={{ color: '#15803d', fontSize: '10px', fontWeight: 600, marginTop: '2px' }}>
                              📍 Est. Arrival: {item.estimatedArrival}
                            </div>
                          )}
                          {item.journeyDuration && (
                            <div style={{ color: '#64748b', fontSize: '10px', fontWeight: 500, marginTop: '1px' }}>
                              ⏱ {item.journeyDuration}
                            </div>
                          )}
                        </div>
                        <div className="schedule-details">
                          <div className="schedule-dest-group">
                            <div className="schedule-dest-text">
                              <span className="dest-dot" style={{ background: 'var(--primary-red)' }} />
                              <div style={{ fontWeight: 700, color: '#0f172a' }}>{item.fromLocation}</div>
                              <div style={{ color: '#64748b', fontSize: '11px' }}>{item.fromSub}</div>
                              {item.busNumber && (
                                <div style={{ fontSize: '11px', color: '#1e3a8a', marginTop: '2px', fontWeight: 600 }}>
                                  🚌 {item.busNumber} · Route {item.route}
                                </div>
                              )}
                              {item.shiftTime && (
                                <div style={{ fontSize: '11px', color: '#15803d', marginTop: '2px', fontWeight: 600 }}>
                                  🕒 Shift: {item.shiftTime}
                                </div>
                              )}
                              {item.shiftName && (
                                <div style={{ fontSize: '10px', color: '#64748b', marginTop: '1px', textTransform: 'uppercase' }}>
                                  Shift: {item.shiftName}
                                </div>
                              )}
                            </div>
                          </div>
                          <button
                            className="schedule-gps-btn"
                            onClick={(e) => { e.stopPropagation(); openGpsDashboard() }}
                            title="Open GPS Dashboard"
                          >
                            <MapPin size={12} />
                            <span>GPS</span>
                          </button>
                          <div className="schedule-dest-group">
                            <div className="schedule-dest-text">
                              <span className="dest-dot" style={{ background: 'var(--dark-bg)' }} />
                              <div style={{ fontWeight: 700, color: '#0f172a' }}>{item.toLocation}</div>
                              <div style={{ color: '#64748b', fontSize: '11px' }}>{item.toSub}</div>
                              {item.driver && (
                                <div style={{ fontSize: '11px', color: '#15803d', marginTop: '2px', fontWeight: 600 }}>
                                  👤 Driver: {item.driver}
                                </div>
                              )}
                              {item.capacity !== undefined && (
                                <div style={{ fontSize: '11px', color: '#15803d', marginTop: '1px', fontWeight: 600 }}>
                                  💺 Seats: {item.available}/{item.capacity} available
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div
                          className="status-badge"
                          style={item.status === 'Delayed' ? { background: '#FFF3E0', color: '#E65100' } : {}}
                        >
                          {item.status}
                        </div>
                      </div>
                    ))}
                    {filteredSchedule.length === 0 && (
                      <p style={{ textAlign: 'center', color: 'var(--text-gray)', padding: '20px', fontSize: '12px' }}>
                        {scheduleLoading ? 'Loading schedules…' : 'No schedules found.'}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* DESKTOP QUICK ACTIONS */}
          {!isMobile && (
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                minWidth: '92px',
                flexShrink: 0,
                paddingTop: '32px',
              }}
            >
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('bookSeat')}>
                <span style={actionIconStyle}><Armchair size={16} strokeWidth={2} /></span>
                <span>Book Bus</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('myBookings')}>
                <span style={actionIconStyle}><Calendar size={16} strokeWidth={2} /></span>
                <span>My Bookings</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('trackBus')}>
                <span style={actionIconStyle}><Navigation size={16} strokeWidth={2} /></span>
                <span>GPS</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('support')}>
                <span style={actionIconStyle}><Headset size={16} strokeWidth={2} /></span>
                <span>Support</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* MOBILE BOTTOM NAV */}
      {isMobile && (
        <div className="bottom-nav">
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('bookSeat')}>
            <span style={mobileTabIconStyle}><Armchair size={18} /></span>
            <span>Book</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('myBookings')}>
            <span style={mobileTabIconStyle}><Calendar size={18} /></span>
            <span>Bookings</span>
          </button>
          <button
            type="button"
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '2px',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              color: '#D32F2F',
              fontFamily: 'inherit',
              fontSize: '9px',
              fontWeight: 600,
              flex: '0 0 auto',
              minWidth: '56px',
              position: 'relative',
              top: '-14px',
            }}
            onClick={() => setModal('qr')}
          >
            <span
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: '#D32F2F',
                color: '#fff',
                boxShadow: '0 6px 18px rgba(211,47,47,0.4)',
              }}
            >
              <QrCode size={22} />
            </span>
            <span style={{ color: '#D32F2F', marginTop: '2px' }}>My Pass</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('trackBus')}>
            <span style={mobileTabIconStyle}><Navigation size={18} /></span>
            <span>GPS</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('support')}>
            <span style={mobileTabIconStyle}><Headset size={18} /></span>
            <span>Support</span>
          </button>
        </div>
      )}

      {/* TOAST */}
      <div
        className={`toast ${toast.show ? 'show' : ''}`}
        style={{
          bottom: isMobile ? '110px' : '100px',
          maxWidth: isMobile ? '90vw' : 'auto',
          whiteSpace: isMobile ? 'normal' : 'nowrap',
          textAlign: 'center',
        }}
      >
        {toast.message}
      </div>

      {/* MODALS */}
      {modal === 'gps' && (
        <Modal onClose={closeModal} fullscreen>
          <div className="modal-header">
            <h3><Navigation size={18} /> GPS Dashboard — Live Vehicles</h3>
            <button className="close-modal" onClick={closeModal}><X size={18} /></button>
          </div>
          <div className="modal-body" style={{ padding: 0, height: 'calc(100% - 56px)', overflow: 'hidden' }}>
            <GpsDashboard
              isMobile={isMobile}
              externalVehicles={gpsVehicles}
              externalLoading={gpsLoading}
              externalError={gpsError}
              externalLastUpdated={null}
            />
          </div>
        </Modal>
      )}

      {modal === 'map' && (
        <Modal onClose={closeModal} fullscreen>
          <div className="modal-header">
            <h3><Map size={18} /> Live Bus Tracking</h3>
            <button className="close-modal" onClick={closeModal}><X size={18} /></button>
          </div>
          <div className="modal-body map-modal-body">
            <iframe
              src="https://www.openstreetmap.org/export/embed.html?bbox=79.25%2C19.90%2C79.35%2C19.98&amp;layer=mapnik&amp;marker=19.9445%2C79.2880"
              style={{ border: 'none' }}
              title="Live Map"
            />
          </div>
          <div className="map-modal-footer">
            <span>Start: <strong>{mapEndpoints.start}</strong></span>
            <span>End: <strong>{mapEndpoints.end}</strong></span>
          </div>
        </Modal>
      )}

      {/* BOOKING MODAL */}
      {modal === 'booking' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Armchair} title="Book a Bus Seat" onClose={closeModal} />
          <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>

            {/* STEP 1: SOURCE */}
            {bookStep === STEP.SOURCE && (
              <>
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Choose Source</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>Select your boarding source</p>
                </div>
                {routesLoading ? (
                  <LoadingState label="Loading sources…" />
                ) : routes.length === 0 ? (
                  <EmptyState icon={MapPin} label="No sources available." />
                ) : (
                  <OptionGrid>
                    {routes.map((route) => (
                      <OptionCard
                        key={route.id}
                        selected={selectedSource?.id === route.id}
                        onClick={() => {
                          setSelectedSource(route)
                          setBookStep(STEP.BOARDING_STOP)
                          loadBoardingStops(route.source || route.source_name || route.name || route.source || 'Source')
                        }}
                        icon={RouteIcon}
                        iconColor="#b91c1c"
                        title={route.route_name || route.source_name || route.name || route.source || 'Source'}
                        subtitle={`Route ${route.route_number}: ${route.source} → ${route.destination}`}
                        footer={`${route.total_stops || route.stops_count || 0} stops available`}
                      />
                    ))}
                  </OptionGrid>
                )}
              </>
            )}

            {/* STEP 2: BOARDING STOP */}
            {bookStep === STEP.BOARDING_STOP && (
              <>
                <StepHeader
                  onBack={() => setBookStep(STEP.SOURCE)}
                  backLabel="Back to Source"
                  rightLabel={selectedSource?.source_name || selectedSource?.name || selectedSource?.source || 'Selected Source'}
                />
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Choose Boarding Stop</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>Select your boarding point</p>
                </div>
                {boardingStopsLoading ? (
                  <LoadingState label="Loading boarding stops…" />
                ) : boardingStops.length === 0 ? (
                  <EmptyState icon={MapPin} label="No boarding stops available." />
                ) : (
                  <OptionGrid>
                    {boardingStops.map((stop) => (
                      <OptionCard
                        key={stop.stop_id || stop.id}
                        selected={selectedBoardingStop?.stop_id === stop.stop_id || selectedBoardingStop?.id === stop.id}
                        onClick={() => {
                          setSelectedBoardingStop(stop)
                          setBookStep(STEP.SHIFT)
                        }}
                        icon={MapPin}
                        iconColor="#1e3a8a"
                        title={stop.stop_name || stop.name || 'Stop'}
                        subtitle={stop.stop_code || stop.code || '—'}
                        footer="Pickup Point"
                        footerColor="#b91c1c"
                      />
                    ))}
                  </OptionGrid>
                )}
              </>
            )}

            {/* STEP 3: SHIFT */}
            {bookStep === STEP.SHIFT && (
              <>
                <StepHeader
                  onBack={() => setBookStep(STEP.BOARDING_STOP)}
                  backLabel="Back to Boarding Stop"
                  rightLabel={selectedBoardingStop?.stop_name || selectedBoardingStop?.name || 'Selected Stop'}
                />
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Choose Shift</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>Select the shift timing for your journey</p>
                </div>
                {shiftsLoading ? (
                  <LoadingState label="Loading shifts…" />
                ) : shifts.length === 0 ? (
                  <EmptyState icon={Bus} label="No shifts available." />
                ) : (
                  <OptionGrid>
                    {shifts.map((shift) => (
                      <OptionCard
                        key={shift.id}
                        selected={selectedShift?.id === shift.id}
                        onClick={() => {
                          setSelectedShift(shift)
                          setShiftStartTime(shift.start_time || '')
                          setShiftEndTime(shift.end_time || '')
                          setBookStep(STEP.DATES)
                          loadAvailableBuses(
                            selectedSource?.source || selectedSource?.source_name || selectedSource?.name || selectedSource?.source,
                            selectedBoardingStop?.stop_id || selectedBoardingStop?.id,
                            shift.id,
                            bookingDates
                          )
                        }}
                        icon={Bus}
                        iconColor="#1e3a8a"
                        title={shift.shift_name || shift.name || 'Shift'}
                        subtitle={shift.shift_code || shift.code || '—'}
                        footer={`${shift.start_time} – ${shift.end_time}`}
                        footerColor="#b91c1c"
                        chevron
                      />
                    ))}
                  </OptionGrid>
                )}
              </>
            )}

            {/* STEP 4: DATES */}
            {bookStep === STEP.DATES && (
              <>
                <StepHeader
                  onBack={() => setBookStep(STEP.SHIFT)}
                  backLabel="Back to Shift"
                  rightLabel={selectedShift?.shift_name || selectedShift?.name || 'Selected Shift'}
                />
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Choose Travel Dates</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>Select the dates you want to travel</p>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
                  {[15, 30].map((days) => (
                    <button
                      key={days}
                      type="button"
                      onClick={() => setTravelDaysCount(days)}
                      style={pillStyle(travelDaysCount === days)}
                    >
                      {days} Days
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setTravelDaysCount('month')}
                    style={pillStyle(travelDaysCount === 'month')}
                  >
                    Whole Month
                  </button>
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={labelStyle}>Select Booking Dates</label>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(95px, 1fr))', gap: 8 }}>
                    {generateBookingDates().map((date) => {
                      const isSelected = bookingDates.includes(date)
                      return (
                        <button
                          key={date}
                          type="button"
                          onClick={() => {
                            setBookingDates(
                              isSelected
                                ? bookingDates.filter((d) => d !== date)
                                : [...bookingDates, date]
                            )
                          }}
                          style={dateChipStyle(isSelected)}
                        >
                          {new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                        </button>
                      )
                    })}
                  </div>                </div>

                <div style={{ marginBottom: 16 }}>
                  <label style={labelStyle}>Pass Valid From</label>
                  <input
                    type="date"
                    value={passValidFrom}
                    onChange={(e) => setPassValidFrom(e.target.value)}
                    style={inputStyle}
                  />
                </div>
                <div style={{ marginBottom: 16 }}>
                  <label style={labelStyle}>Pass Valid To</label>
                  <input
                    type="date"
                    value={passValidTo}
                    onChange={(e) => setPassValidTo(e.target.value)}
                    style={inputStyle}
                  />
                </div>

                <div style={summaryBoxStyle}>
                  <SummaryCell label="Pass Valid From" value={passValidFrom || '—'} />
                  <SummaryCell label="Pass Valid To" value={passValidTo || '—'} />
                  <SummaryCell label="Booking Dates" value={`${bookingDates.length} selected`} />
                  <SummaryCell
                    label="Travel Period"
                    value={travelDaysCount === 'month' ? 'Whole Month' : `${travelDaysCount} Days`}
                  />
                </div>

                <button
                  type="button"
                  onClick={goToBusStep}
                  className="btn-primary"
                  disabled={bookingLoading}
                  style={{ marginTop: 16 }}
                >
                  Next: Select Bus
                </button>
              </>
            )}

            {/* STEP 5: BUS */}
            {bookStep === STEP.BUS && (
              <>
                <StepHeader
                  onBack={() => setBookStep(STEP.DATES)}
                  backLabel="Back to Dates"
                  rightLabel={selectedShift?.shift_name || selectedShift?.name || 'Selected Shift'}
                />
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Choose Bus</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>Select the bus for your journey</p>
                </div>
                {busesLoading ? (
                  <LoadingState label="Loading buses…" />
                ) : buses.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '30px 0' }}>
                    <Bus size={32} style={{ color: '#94a3b8', marginBottom: 12 }} />
                    <p style={{ color: '#64748b' }}>No buses available for this route and shift.</p>
                    <button
                      type="button"
                      onClick={() =>
                        loadAvailableBuses(
                          selectedSource?.source || selectedSource?.source_name || selectedSource?.name || selectedSource?.source,
                          selectedBoardingStop?.stop_id || selectedBoardingStop?.id,
                          selectedShift?.id,
                          bookingDates
                        )
                      }
                      className="btn-primary"
                      style={{ marginTop: 16 }}
                    >
                      Retry Loading Buses
                    </button>
                  </div>
                ) : (
                  <OptionGrid>
                    {buses.map((bus) => (
                      <OptionCard
                        key={bus.bus_id || bus.id}
                        selected={selectedBus?.bus_id === bus.bus_id}
                        onClick={() => setSelectedBus(bus)}
                        icon={Bus}
                        iconColor="#1e3a8a"
                        title={bus.bus_number || bus.number || `Bus #${bus.bus_id}`}
                        subtitle={`Route ${bus.route_number || bus.route?.route_number || '—'}`}
                        footer={bus.shift_name || bus.shift?.shift_name || 'General Shift'}
                        footerColor="#b91c1c"
                        extra={
                          bus.seating_capacity
                            ? `💺 ${bus.seating_capacity} Seats`
                            : undefined
                        }
                      />
                    ))}
                  </OptionGrid>
                )}
                {selectedBus && (
                  <div style={{ ...summaryBoxStyle, justifyContent: 'space-between' }}>
                    <div>
                      <div style={summaryLabelStyle}>Selected Bus</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>
                        {selectedBus.bus_number || selectedBus.number || `Bus #${selectedBus.id}`}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setBookStep(STEP.CONFIRM)}
                      className="btn-primary"
                      disabled={bookingLoading}
                    >
                      Next: Confirm & Submit
                    </button>
                  </div>
                )}
              </>
            )}

            {/* STEP 6: CONFIRM */}
            {bookStep === STEP.CONFIRM && (
              <>
                <div style={{ marginBottom: 16 }}>
                  <div className="section-title-dark">Review & Confirm Booking</div>
                  <p style={{ color: '#64748b', fontSize: '13px', marginBottom: 14 }}>
                    Review your booking details before submitting
                  </p>
                </div>
                <div style={reviewBoxStyle}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Bus size={20} style={{ color: '#1e3a8a' }} />
                      <div>
                        <div style={{ fontWeight: 700, color: '#0f172a' }}>
                          {selectedBus?.bus_number || selectedBus?.number || 'Bus'}
                        </div>
                        <div style={{ fontSize: '12px', color: '#64748b' }}>
                          {selectedBus?.route_number || selectedBus?.route?.route_number || ''}
                        </div>
                      </div>
                    </div>
                    <div style={{ fontSize: '13px', color: '#0f172a' }}>
                      {selectedShift?.shift_name || selectedShift?.name || 'Shift'}
                    </div>
                    <div style={{ fontSize: '13px', color: '#0f172a' }}>
                      {shiftStartTime} – {shiftEndTime}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MapPin size={20} style={{ color: '#b91c1c' }} />
                    <div style={{ fontSize: '12px', color: '#0f172a' }}>
                      {selectedBoardingStop?.stop_name || selectedBoardingStop?.name || '—'}
                    </div>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
                    <SummaryCell label="Source" value={selectedSource?.source_name || selectedSource?.name || selectedSource?.source || '—'} inline />
                    <SummaryCell label="Boarding Stop" value={selectedBoardingStop?.stop_name || selectedBoardingStop?.name || '—'} inline />
                    <SummaryCell label="Travel Dates" value={`${bookingDates.length} days`} inline />
                  </div>
                  <div style={{ marginTop: 16, padding: 14, background: '#fef2f2', borderRadius: 12, border: '1px solid #fecaca' }}>
                    <div style={{ fontSize: 11, color: '#b91c1c', fontWeight: 800, textTransform: 'uppercase', marginBottom: 8 }}>
                      Important
                    </div>
                    <div style={{ fontSize: '13px', color: '#7f1d1d', lineHeight: 1.5 }}>
                      Your application will be reviewed by admin. You will receive your QR code pass via email once approved. You can track the status in "My Bookings."
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
                  <button
                    type="button"
                    onClick={() => setBookStep(STEP.BUS)}
                    style={{
                      flex: 1,
                      padding: '12px',
                      borderRadius: '10px',
                      border: '1px solid var(--color-border)',
                      background: '#fff',
                      color: '#0f172a',
                      fontWeight: 700,
                      cursor: 'pointer',
                    }}
                  >
                    Back to Bus Selection
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmitBooking}
                    className="btn-primary"
                    disabled={bookingLoading}
                    style={{ flex: 1 }}
                  >
                    {bookingLoading ? 'Submitting…' : 'Submit for Approval'}
                  </button>
                </div>
              </>
            )}
          </div>
        </Modal>
      )}

      {/* MY BOOKINGS */}
      {modal === 'myBookings' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Calendar} title="My Bookings" onClose={closeModal} />
          <div className="modal-body">
            {bookingsLoading ? (
              <LoadingState label="Loading bookings…" />
            ) : myBookings.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '20px 0' }}>
                <Bus size={32} style={{ color: '#94a3b8', marginBottom: 12 }} />
                <p style={{ color: '#64748b' }}>No bookings found.</p>
                <button
                  className="btn-primary"
                  style={{ marginTop: 12 }}
                  onClick={async () => { closeModal(); await openBookBus() }}
                >
                  Book a Bus
                </button>
              </div>
            ) : (
              myBookings.map((b, idx) => (
                <BookingCard
                  key={b.id || b.application_number || idx}
                  tripId={b.application_number || b.id || `Booking #${idx + 1}`}
                  route={
                    b.route?.route_name ||
                    b.route?.route_number ||
                    (b.pickup_stop?.stop_name && b.drop_stop?.stop_name
                      ? `${b.pickup_stop.stop_name} → ${b.drop_stop.stop_name}`
                      : b.fromLocation && b.toLocation
                      ? `${b.fromLocation} → ${b.toLocation}`
                      : '—')
                  }
                  date={
                    b.submitted_at || b.created_at || b.pass_valid_from
                      ? new Date(b.submitted_at || b.created_at || b.pass_valid_from).toLocaleDateString('en-IN', {
                          day: '2-digit', month: 'short', year: 'numeric',
                        })
                      : '—'
                  }
                  status={b.status || 'Pending'}
                />
              ))
            )}
          </div>
        </Modal>
      )}

      {/* SUPPORT */}
      {modal === 'support' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Headset} title="Support" onClose={closeModal} />
          <div className="modal-body">
            {supportSubmitted ? (
              <div style={{ textAlign: 'center', padding: '20px 0' }}>
                <CircleCheck size={48} style={{ color: '#2E7D32', marginBottom: 12 }} />
                <h4 style={{ color: '#2E7D32', marginBottom: 8 }}>Ticket Submitted</h4>
                <p style={{ color: '#64748b', fontSize: 13 }}>Your support request has been received.</p>
                <button
                  className="btn-primary"
                  onClick={() => { setSupportSubmitted(false); closeModal() }}
                >
                  OK
                </button>
              </div>
            ) : (
              <>
                <div className="notification-item" style={{ borderBottom: 'none', padding: '0 0 15px 0' }}>
                  <div className="notif-icon" style={{ background: '#E3F2FD', color: '#1976D2' }}>
                    <Phone size={17} />
                  </div>
                  <div className="notif-content">
                    <h4>Call Transport Desk</h4>
                    <p>+91 1234512345</p>
                  </div>
                </div>
                <div className="notification-item" style={{ borderBottom: 'none', padding: '0 0 15px 0' }}>
                  <div className="notif-icon" style={{ background: '#E8F5E9', color: '#2E7D32' }}>
                    <Mail size={17} />
                  </div>
                  <div className="notif-content">
                    <h4>Email Support</h4>
                    <p>traveldesk@lloyds.in</p>
                  </div>
                </div>
                <div className="form-group" style={{ marginTop: 20 }}>
                  <label>Subject</label>
                  <input
                    type="text"
                    placeholder="Enter subject"
                    value={supportSubject}
                    onChange={(e) => setSupportSubject(e.target.value)}
                  />
                </div>
                <div className="form-group" style={{ marginBottom: 20 }}>
                  <label>Describe your issue</label>
                  <textarea
                    rows={3}
                    placeholder="Enter issue details..."
                    value={supportMessage}
                    onChange={(e) => setSupportMessage(e.target.value)}
                  />
                </div>
                <button
                  className="btn-primary"
                  disabled={supportSubmitting}
                  onClick={async () => {
                    setSupportSubmitting(true)
                    try {
                      await submitSupportTicket({ subject: supportSubject, message: supportMessage })
                      setSupportSubmitted(true)
                      setSupportSubject('')
                      setSupportMessage('')
                    } catch (error) {
                      showToast(error.response?.data?.message || 'Failed to submit support ticket')
                    } finally {
                      setSupportSubmitting(false)
                    }
                  }}
                >
                  {supportSubmitting ? 'Submitting…' : 'Submit Ticket'}
                </button>
              </>
            )}
          </div>
        </Modal>
      )}

      {/* QR */}
      {modal === 'qr' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={QrCode} title="Scan to the Board" onClose={closeModal} />
          <div className="modal-body qr-container">
            <DigitalPassCard app={approved} />
          </div>
        </Modal>
      )}

      {/* NOTIFICATIONS */}
      {modal === 'notifications' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Bell} title="Notifications" onClose={closeModal} />
          <div className="modal-body">
            <ul className="notification-list">
              <NotificationItem
                icon={Bus}
                title="Bus Approaching"
                text="Your bus MH 34 AB 1234 is 5 minutes away from Lloyds Colony."
                time="Just now"
              />
              <NotificationItem
                icon={TriangleAlert}
                iconBg="#FFF3E0"
                iconColor="#E65100"
                title="Delay Alert"
                text="Bus MH 34 AB 7890 delayed by 15 mins due to heavy traffic."
                time="10 mins ago"
              />
              <NotificationItem
                icon={CircleCheck}
                iconBg="#E8F5E9"
                iconColor="#2E7D32"
                title="Trip Completed"
                text="You have successfully completed the trip TRIP-1255."
                time="2 hours ago"
              />
            </ul>
          </div>
        </Modal>
      )}

      {/* PROFILE */}
      {modal === 'profile' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={User} title="My Profile" onClose={closeModal} />
          <div className="modal-body">
            <div className="profile-header">
              <div className="profile-avatar"><CircleUser size={36} /></div>
              <h2>{fullName}</h2>
              <p>Employee ID: {employeeId}</p>
            </div>
            <div className="profile-details">
              <div className="profile-row"><span>Department</span><span>Operations</span></div>
              <div className="profile-row"><span>Shift</span><span>General (9AM - 6PM)</span></div>
              <div className="profile-row"><span>Phone</span><span>+91 98765 43210</span></div>
              <div className="profile-row"><span>Email</span><span>rahul.v@lloyds.in</span></div>
            </div>
          </div>
        </Modal>
      )}

      {/* FULL SCHEDULE */}
      {modal === 'fullSchedule' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={CalendarDays} title="Full Schedule - Today" onClose={closeModal} />
          <div className="modal-body">
            {filteredSchedule.map((item) => (
              <ScheduleCard
                key={item.id}
                time={item.time}
                route={`${item.fromLocation} → ${item.toLocation}`}
                busNumber={item.busNumber}
                routeCode={item.route}
                driver={item.driver}
                capacity={item.capacity}
                available={item.available}
                status={item.status}
                shiftTime={item.shiftTime}
                estimatedArrival={item.estimatedArrival}
                journeyDuration={item.journeyDuration}
                fromLocation={item.fromLocation}
                fromSub={item.fromSub}
                toLocation={item.toLocation}
                toSub={item.toSub}
              />
            ))}
            {filteredSchedule.length === 0 && (
              <p style={{ textAlign: 'center', color: 'var(--text-gray)', padding: '20px', fontSize: '12px' }}>
                {scheduleLoading ? 'Loading schedules…' : 'No schedules found.'}
              </p>
            )}
          </div>
        </Modal>
      )}
    </div>
  )
}

// ============================================================
// REUSABLE STYLE HELPERS
// ============================================================
const pillStyle = (active) => ({
  padding: '10px 16px',
  borderRadius: '10px',
  border: `1px solid ${active ? '#b91c1c' : 'var(--color-border)'}`,
  background: active ? '#fef2f2' : '#fff',
  color: active ? '#b91c1c' : '#64748b',
  fontWeight: active ? 800 : 600,
  fontSize: '13px',
  cursor: 'pointer',
  transition: 'all 0.2s ease',
})

const dateChipStyle = (active) => ({
  padding: '10px',
  borderRadius: '8px',
  background: active ? '#fef2f2' : '#f8fafc',
  border: `2px solid ${active ? '#b91c1c' : 'var(--color-border)'}`,
  color: active ? '#b91c1c' : '#64748b',
  fontWeight: active ? 800 : 500,
  fontSize: '12px',
  cursor: 'pointer',
  transition: 'all 0.2s ease',
})

const labelStyle = {
  fontSize: '12px',
  fontWeight: 700,
  color: '#0f172a',
  marginBottom: 8,
  display: 'block',
}

const inputStyle = {
  padding: '10px',
  borderRadius: '8px',
  border: '1px solid var(--color-border)',
  fontSize: '13px',
  width: '100%',
}

const summaryBoxStyle = {
  marginTop: 16,
  padding: 14,
  background: '#fef2f2',
  borderRadius: 12,
  border: '1px solid #fecaca',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  flexWrap: 'wrap',
}

const summaryLabelStyle = {
  fontSize: 11,
  color: '#b91c1c',
  fontWeight: 800,
  textTransform: 'uppercase',
}

const reviewBoxStyle = {
  background: '#f8fafc',
  borderRadius: '12px',
  padding: '20px',
  border: '1px solid var(--color-border)',
  marginBottom: 20,
}

const SummaryCell = ({ label, value, inline }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: inline ? 1 : 'unset' }}>
    <div style={summaryLabelStyle}>{label}</div>
    <div style={{ fontSize: 14, fontWeight: 700, color: '#0f172a' }}>{value}</div>
  </div>
)

const OptionGrid = ({ children }) => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 14 }}>
    {children}
  </div>
)

const OptionCard = ({ selected, onClick, icon: Icon, iconColor, title, subtitle, footer, footerColor, extra, chevron }) => (
  <button
    type="button"
    onClick={onClick}
    style={{
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      padding: '16px 18px',
      border: selected ? '2px solid #b91c1c' : '1px solid var(--color-border)',
      borderRadius: '14px',
      background: selected ? '#fef2f2' : '#fff',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      boxShadow: selected ? '0 4px 16px rgba(185, 28, 28, 0.15)' : '0 2px 8px rgba(0,0,0,0.04)',
      textAlign: 'left',
      fontFamily: 'inherit',
    }}
  >
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
      <Icon size={18} style={{ color: iconColor }} />
      <span style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>{title}</span>
    </div>
    <div style={{ color: '#64748b', fontSize: '12px', fontWeight: 600 }}>{subtitle}</div>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, marginTop: 6 }}>
      <span style={{ color: footerColor || '#64748b', fontSize: '11px', fontWeight: 800, textTransform: footerColor ? 'uppercase' : 'none', letterSpacing: '0.05em' }}>
        {footer}
      </span>
      {extra && (
        <span style={{ color: '#15803d', fontSize: '11px', fontWeight: 800, background: '#f0fdf4', padding: '4px 8px', borderRadius: '8px' }}>
          {extra}
        </span>
      )}
      {chevron && <ChevronRight size={14} style={{ color: '#94a3b8' }} />}
    </div>
  </button>
)

const StepHeader = ({ onBack, backLabel, rightLabel }) => (
  <div style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
    <button
      type="button"
      onClick={onBack}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        background: 'transparent',
        border: 'none',
        color: '#64748b',
        cursor: 'pointer',
        fontSize: '13px',
        fontWeight: 600,
        fontFamily: 'inherit',
      }}
    >
      <ChevronLeft size={14} />
      <span>{backLabel}</span>
    </button>
    <div style={{ flex: 1, height: 1, background: '#e2e8f0', margin: '0 12px' }} />
    <div style={{ color: '#64748b', fontSize: '13px', fontWeight: 600 }}>{rightLabel}</div>
  </div>
)

const LoadingState = ({ label }) => (
  <div style={{ textAlign: 'center', padding: '30px 0' }}>
    <RefreshCw size={24} className="spinning" />
    <p style={{ color: '#64748b', marginTop: 8 }}>{label}</p>
  </div>
)

const EmptyState = ({ icon: Icon, label }) => (
  <div style={{ textAlign: 'center', padding: '30px 0' }}>
    <Icon size={32} style={{ color: '#94a3b8', marginBottom: 12 }} />
    <p style={{ color: '#64748b' }}>{label}</p>
  </div>
)

// ============================================================
// SUB-COMPONENTS
// ============================================================
const Modal = ({ children, onClose, fullscreen }) => (
  <div
    className="modal-overlay active"
    onClick={(e) => e.target === e.currentTarget && onClose()}
    style={fullscreen ? { padding: 0 } : {}}
  >
    <div className="modal-content" style={fullscreen ? { borderRadius: 0 } : {}}>
      {children}
    </div>
  </div>
)

const ModalHeader = ({ icon: Icon, title, onClose }) => (
  <div className="modal-header">
    <h3><Icon size={18} /> {title}</h3>
    <button className="close-modal" onClick={onClose}><X size={18} /></button>
  </div>
)

const BookingCard = ({ tripId, route, date, status = 'Pending' }) => {
  const statusStyle = (() => {
    switch (status) {
      case 'APPROVED':
      case 'Confirmed':
        return { background: '#E8F5E9', color: '#2E7D32' }
      case 'PENDING_APPROVAL':
      case 'Pending':
        return { background: '#FFF8E1', color: '#F57F17' }
      case 'REJECTED':
      case 'Cancelled':
        return { background: '#FFEBEE', color: '#C62828' }
      case 'Delayed':
        return { background: '#FFF3E0', color: '#E65100' }
      default:
        return undefined
    }
  })()
  return (
    <div className="card" style={{ boxShadow: 'none', border: '1px solid var(--border-color)', marginBottom: 15 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <strong style={{ fontSize: 13 }}>{tripId}</strong>
        <span className="status-badge" style={statusStyle}>{status}</span>
      </div>
      <p style={{ fontSize: 12, color: 'var(--text-gray)', marginBottom: 5 }}>{route}</p>
      <p style={{ fontSize: 11, color: 'var(--text-dark)', fontWeight: 500 }}>{date}</p>
    </div>
  )
}

const NotificationItem = ({ icon: Icon, title, text, time, iconBg, iconColor }) => (
  <li className="notification-item">
    <div className="notif-icon" style={{ background: iconBg || '#E3F2FD', color: iconColor || 'var(--blue)' }}>
      <Icon size={17} />
    </div>
    <div className="notif-content">
      <h4>{title}</h4>
      <p>{text}</p>
      <span className="notif-time">{time}</span>
    </div>
  </li>
)

const ScheduleCard = ({
  time, route, busNumber, routeCode, driver, capacity, available,
  status = 'On Time', shiftTime, estimatedArrival, journeyDuration,
  fromLocation, fromSub, toLocation, toSub,
}) => (
  <div className="card" style={{ boxShadow: 'none', border: '1px solid var(--border-color)', marginBottom: 12 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
      <div>
        <strong style={{ fontSize: 14 }}>{time}</strong>
        {shiftTime && <div style={{ color: '#64748b', fontSize: '11px', marginTop: 2 }}>🕒 Shift: {shiftTime}</div>}
        {estimatedArrival && <div style={{ color: '#15803d', fontSize: '11px', fontWeight: 600, marginTop: 2 }}>📍 Est. Arrival: {estimatedArrival}</div>}
        {journeyDuration && <div style={{ color: '#64748b', fontSize: '10px', fontWeight: 500, marginTop: 1 }}>⏱ {journeyDuration}</div>}
      </div>
      <span className="status-badge" style={status === 'Delayed' ? { background: '#FFF3E0', color: '#E65100' } : {}}>
        {status}
      </span>
    </div>
    <p style={{ fontSize: 13, color: '#0f172a', fontWeight: 700, marginBottom: 6 }}>
      {fromLocation} <span style={{ color: '#64748b', fontWeight: 500 }}>{fromSub}</span>
      {' → '}
      {toLocation} <span style={{ color: '#64748b', fontWeight: 500 }}>{toSub}</span>
    </p>
    {(busNumber || driver || capacity) && (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', fontSize: '11px', color: 'var(--text-gray)' }}>
        {busNumber && <span>🚌 {busNumber} {routeCode && `(${routeCode})`}</span>}
        {driver && <span>👤 {driver}</span>}
        {typeof available === 'number' && typeof capacity === 'number' && (
          <span>💺 {available}/{capacity} seats</span>
        )}
      </div>
    )}
  </div>
)