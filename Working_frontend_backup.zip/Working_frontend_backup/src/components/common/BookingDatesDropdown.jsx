import './BookingDatesDropdown.css'

export default function BookingDatesDropdown({ dates, passValidFrom, passValidTo }) {
  const sorted = [
    ...(passValidFrom && passValidTo ? [passValidFrom, passValidTo] : []),
    ...(dates || []),
  ]
    .filter(Boolean)
    .sort()

  const display = sorted.length
    ? sorted.map((d) => {
        const date = new Date(`${d}T00:00:00`)
        return date.toLocaleDateString('en-GB', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        })
      })
    : ['No dates selected']

  return (
    <select className="booking-dates-dropdown" defaultValue="" aria-label="Booking dates">
      <option value="" disabled>{display.length} date{display.length === 1 ? '' : 's'}</option>
      {display.map((label, idx) => (
        <option key={idx} value={sorted[idx]}>{label}</option>
      ))}
    </select>
  )
}
