import { useState, useEffect, useCallback, useRef } from 'react'
import {
  MapContainer, TileLayer, Marker, Popup, useMap,
} from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { Navigation, RefreshCw, MapPin } from 'lucide-react'

/* ============================================
   FIX LEAFLET DEFAULT MARKER ICONS
   ============================================ */
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

/* ============================================
   API CONFIG
   ============================================ */
const API_BASE = 'http://localhost:5000/api'
const WHEELSEYE_API_URL =
  'https://api.wheelseye.com/currentLoc?accessToken=98a3355b-4498-48bb-8b70-7b0b04475788'

/* ============================================
   LIVE VEHICLES HOOK
   ============================================ */
function useLiveVehicles(active = true, intervalMs = 15000) {
  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [lastUpdated, setLastUpdated] = useState(null)
  const [, setTick] = useState(0)

  const abortRef = useRef(null)
  const timerRef = useRef(null)

  const fetchOnce = useCallback(async () => {
    if (abortRef.current) abortRef.current.abort()
    const controller = new AbortController()
    abortRef.current = controller

    setLoading(true)
    try {
      let list = null

      // 1) Try backend /api/vehicles first
      try {
        const res = await fetch(`${API_BASE}/vehicles`, { signal: controller.signal })
        if (res.ok) {
          const json = await res.json()
          list = json?.data?.list ?? json?.data ?? json?.list ?? []
        }
      } catch (err) { /* ignore, fallback */ }

      // 2) Try Wheelseye directly
      if (!list || list.length === 0) {
        try {
          const res = await fetch(WHEELSEYE_API_URL, { signal: controller.signal })
          if (res.ok) {
            const json = await res.json()
            list = json?.data?.data?.list ?? json?.data?.list ?? []
          }
        } catch (err) { /* ignore */ }
      }

      if (!list) throw new Error('No data source available')

      // Merge by deviceNumber so React reuses DOM nodes
      setVehicles((prev) => {
        const byId = new Map(prev.map((v) => [v.deviceNumber, v]))
        list.forEach((v) => byId.set(v.deviceNumber, v))
        return list.map((v) => byId.get(v.deviceNumber) ?? v)
      })

      setLastUpdated(new Date())
      setError(null)
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'Failed to load vehicle locations')
      }
    } finally {
      setLoading(false)
    }
  }, [])

  // Poll loop
  useEffect(() => {
    if (!active) return

    fetchOnce()

    const start = () => {
      if (timerRef.current) return
      timerRef.current = setInterval(fetchOnce, intervalMs)
    }
    const stop = () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
        timerRef.current = null
      }
    }
    const onVisibility = () => {
      if (document.hidden) stop()
      else {
        fetchOnce()
        start()
      }
    }

    start()
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      stop()
      document.removeEventListener('visibilitychange', onVisibility)
      if (abortRef.current) abortRef.current.abort()
    }
  }, [active, intervalMs, fetchOnce])

  // 1s tick so "Updated Xs ago" re-renders
  useEffect(() => {
    if (!active) return
    const id = setInterval(() => setTick((t) => t + 1), 1000)
    return () => clearInterval(id)
  }, [active])

  return { vehicles, loading, error, lastUpdated, refresh: fetchOnce }
}

/* ============================================
   VEHICLE ICON (L.divIcon)
   ============================================ */
function createVehicleIcon(vehicle, isSelected) {
  const isMoving = (vehicle.speed || 0) > 0

  let bgColor = '#7a8ba3'
  if (isMoving) bgColor = '#10a56a'
  if (isSelected) bgColor = '#1e6fdf'

  const iconHtml = `
    <div style="width:36px;height:36px;border-radius:50% 50% 50% 0;background:${bgColor};transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.25);border:2px solid white;${isMoving ? 'animation:pulse 1.5s infinite' : ''}">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transform:rotate(45deg)">
        <path d="M18 19V7a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v12" />
        <path d="M2 19h20" />
        <path d="M6 19V5" />
        <path d="M18 19V5" />
      </svg>
    </div>
    <style>@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(16,165,106,0.5)}70%{box-shadow:0 0 0 12px rgba(16,165,106,0)}100%{box-shadow:0 0 0 0 rgba(16,165,106,0)}}</style>
  `
  return L.divIcon({
    html: iconHtml,
    className: 'custom-vehicle-marker',
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36],
  })
}

/* ============================================
   MAP CONTROLLER
   ============================================ */
function MapController({ center, zoom }) {
  const map = useMap()
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.setView(center, zoom || map.getZoom())
    }
  }, [center, zoom, map])
  return null
}

/* ============================================
   GPS DASHBOARD COMPONENT
   ============================================ */
export default function GpsDashboard({
  isMobile,
  externalVehicles,
  externalLoading,
  externalError,
  externalLastUpdated,
}) {
  const {
    vehicles: hookVehicles,
    loading: hookLoading,
    error: hookError,
    lastUpdated: hookLastUpdated,
    refresh,
  } = useLiveVehicles(true, 15000)
  const [selectedVehicle, setSelectedVehicle] = useState(null)

  const vehicles =
    externalVehicles && externalVehicles.length > 0
      ? externalVehicles
      : hookVehicles
  const loading = externalLoading != null ? externalLoading : hookLoading
  const error = externalError != null ? externalError : hookError
  const lastUpdated =
    externalLastUpdated != null ? externalLastUpdated : hookLastUpdated

  const validVehicles = (vehicles || []).filter(
    (v) =>
      v &&
      typeof v.latitude === 'number' &&
      typeof v.longitude === 'number' &&
      !isNaN(v.latitude) &&
      !isNaN(v.longitude)
  )


  const center = selectedVehicle
    ? [selectedVehicle.latitude, selectedVehicle.longitude]
    : validVehicles.length
    ? [validVehicles[0].latitude, validVehicles[0].longitude]
    : [19.9369, 79.1193]

  return (
    <div className="dashboard-container gps-dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">GPS Dashboard</h1>
          <p className="dashboard-subtitle">
            Live vehicle locations · {validVehicles.length} on map
          </p>
        </div>
        <div className="dashboard-actions">
          <button
            className="btn btn-ghost btn-sm"
            onClick={refresh}
            disabled={loading}
            title="Refresh"
          >
            <RefreshCw size={16} className={loading ? 'spinning' : ''} />
            {!isMobile && 'Refresh'}
          </button>
        </div>
      </div>

      {error && (
        <div className="alert alert-error" style={{ marginBottom: '1rem' }}>
          <MapPin size={16} /> {error}
        </div>
      )}

      {lastUpdated && (
        <div className="text-muted" style={{ marginBottom: '0.75rem', fontSize: '0.875rem' }}>
          Last updated: {new Date(lastUpdated).toLocaleTimeString()}
        </div>
      )}

      <div
        className={`gps-dashboard-layout ${isMobile ? 'mobile' : ''}`}
        style={{ gridTemplateColumns: isMobile ? '1fr' : '1fr 0' }}
      >
        <div className="gps-map-wrapper">
          <MapContainer
            center={center}
            zoom={13}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapController
              center={
                selectedVehicle
                  ? [selectedVehicle.latitude, selectedVehicle.longitude]
                  : null
              }
              zoom={15}
            />
            {validVehicles.map((v, idx) => (
              <Marker
                key={v.deviceNumber || v.vehicleNumber || idx}
                position={[v.latitude, v.longitude]}
                icon={createVehicleIcon(
                  v,
                  selectedVehicle?.deviceNumber === v.deviceNumber
                )}
                eventHandlers={{ click: () => setSelectedVehicle(v) }}
              >
                <Popup>
                  <div style={{ minWidth: 200 }}>
                    <strong>{v.vehicleNumber || 'N/A'}</strong>
                    <div>Device: {v.deviceNumber || 'N/A'}</div>
                    <div>Speed: {v.speed ?? 0} km/h</div>
                    <div>Ignition: {v.ignition ? 'On' : 'Off'}</div>
                    <div>Type: {v.vehicleType || 'NA'}</div>
                    <div>Vendor: {v.venndorName || v.vendorName || '—'}</div>
                    <div>
                      Updated: {v.dttime || v.createdDateReadable || '—'}
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="gps-list-wrapper">
          <div className="gps-list-header">
            <h3>Vehicles ({vehicles.length})</h3>
          </div>
          <div className="gps-list">
            {vehicles.length === 0 && !loading && (
              <div className="text-muted" style={{ padding: '1rem', textAlign: 'center' }}>
                No vehicles found
              </div>
            )}
            {vehicles.map((v, idx) => (
              <div
                key={v.deviceNumber || v.vehicleNumber || idx}
                className={`gps-list-item ${
                  selectedVehicle?.deviceNumber === v.deviceNumber ? 'active' : ''
                }`}
                onClick={() => setSelectedVehicle(v)}
              >
                <div className="gps-list-item-title">
                  {v.vehicleNumber || 'Unknown'}
                </div>
                <div className="gps-list-item-sub">
                  {v.venndorName || v.vendorCode || ''}
                </div>
                <div className="gps-list-item-meta">
                  <span>{v.speed ?? 0} km/h</span>
                  <span>{v.dttime || v.createdDateReadable || '—'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
