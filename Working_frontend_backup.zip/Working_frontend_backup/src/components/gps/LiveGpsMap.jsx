import { useState, useEffect, useCallback, useMemo } from 'react'
import { MapPin, Bus, Navigation, Users, Clock, Gauge, Radio } from 'lucide-react'
import {
  MapContainer, TileLayer, Marker, Popup, Polyline, Circle,
} from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { fetchWheelseyeVehicles, startWheelseyePolling, getConfig } from '../../services/gpsService'

const DEFAULT_CENTER = [19.9615, 79.2961]

const ROUTE_COORDS = [
  [19.9445, 79.2880],
  [19.9460, 79.3100],
  [19.9480, 79.2850],
  [19.9510, 79.3020],
  [19.9530, 79.2980],
  [19.9555, 79.3120],
  [19.9580, 79.2920],
  [19.9615, 79.2961],
  [19.9650, 79.3080],
  [19.9680, 79.2900],
  [19.9690, 79.3150],
  [19.9720, 79.3055],
  [19.9750, 79.3010],
  [19.9780, 79.2950],
]

const createBusIcon = (bus) => {
  const isActive = bus.status === 'ACTIVE'
  const color = isActive ? '#b91c1c' : '#64748b'
  const pulse = isActive ? 'rgba(185,28,28,0.45)' : 'rgba(100,116,139,0.4)'
  return L.divIcon({
    className: 'emp-gps-marker',
    html: `
      <div class="emp-gps-marker__pulse" style="border-color:${color}; background:${pulse};"></div>
      <div class="emp-gps-marker__inner" style="background:linear-gradient(135deg, ${color} 0%, ${isActive ? '#d94a4a' : '#94a3b8'} 100%);">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M8 6v6"></path>
          <path d="M15 6v6"></path>
          <path d="M12 6v12"></path>
          <rect x="4" y="4" width="16" height="16" rx="2"></rect>
        </svg>
      </div>
      <div class="emp-gps-marker__label">${bus.bus_number}</div>
    `,
    iconSize: [44, 56],
    iconAnchor: [22, 28],
  })
}

const statusColor = (s) => (s === 'ACTIVE' ? '#b91c1c' : '#94a3b8')

export default function LiveGpsMap({ onBusSelect }) {
  const [buses, setBuses] = useState([])
  const [error, setError] = useState('')
  const [mapCenter, setMapCenter] = useState(DEFAULT_CENTER)
  const [selectedBus, setSelectedBus] = useState(null)
  const [pollIntervalMs, setPollIntervalMs] = useState(30000)

  const loadVehicles = useCallback(async () => {
    try {
      const data = await fetchWheelseyeVehicles()
      setBuses(data)
      setError('')
    } catch (e) {
      setError(e.response?.data?.message || e.message || 'Unable to load live buses.')
    }
  }, [])

  useEffect(() => {
    loadVehicles()
    const stop = startWheelseyePolling(setBuses, pollIntervalMs)
    return stop
  }, [loadVehicles, pollIntervalMs])

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const cfg = await getConfig()
        if (mounted) setPollIntervalMs(Math.max(5000, cfg.pollIntervalMs || 30000))
      } catch {}
    })()
    return () => { mounted = false }
  }, [])

  const activeBuses = useMemo(() => buses.filter((b) => b.status === 'ACTIVE'), [buses])
  const avgSpeed = useMemo(() => {
    if (!activeBuses.length) return 0
    return Math.round(activeBuses.reduce((s, b) => s + b.speed, 0) / activeBuses.length)
  }, [activeBuses])

  const handleSelectBus = (bus) => {
    setSelectedBus(bus)
    setMapCenter([bus.lat, bus.lng])
    onBusSelect?.(bus)
  }

  if (error) {
    return (
      <div className="emp-map-error">
        <MapPin size={24} />
        <p>{error}</p>
      </div>
    )
  }

  return (
    <div className="emp-gps-map-wrap">
      <div className="emp-gps-map-header">
        <div className="emp-gps-map__title">
          <Radio size={14} className="emp-live-dot" />
          <span>Live Bus yy Tracking</span>
        </div>
        <div className="emp-gps-map__stats">
          <span className="emp-stat">{activeBuses.length} <small>live</small></span>
          <span className="emp-stat">{avgSpeed} <small>km/h avg</small></span>
        </div>
      </div>

      <div className="emp-gps-map">
        <MapContainer
          center={mapCenter}
          zoom={13}
          className="emp-leaflet-map"
          zoomControl={false}
          scrollWheelZoom
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            maxZoom={19}
          />

          <Polyline
            positions={ROUTE_COORDS}
            pathOptions={{ color: '#b91c1c', weight: 10, opacity: 0.12, lineCap: 'round' }}
          />
          <Polyline
            positions={ROUTE_COORDS}
            pathOptions={{
              color: '#b91c1c', weight: 4, opacity: 0.85,
              dashArray: '10 8', lineCap: 'round',
            }}
          />

          {activeBuses.map((bus) => (
            <Circle
              key={`halo-${bus.bus_id}`}
              center={[bus.lat, bus.lng]}
              radius={180}
              pathOptions={{
                color: '#b91c1c', fillColor: '#b91c1c',
                fillOpacity: 0.08, weight: 0,
              }}
            />
          ))}

          {buses.map((bus) => (
            <Marker
              key={bus.bus_id}
              position={[bus.lat, bus.lng]}
              icon={createBusIcon(bus)}
              eventHandlers={{ click: () => handleSelectBus(bus) }}
            >
              <Popup className="emp-gps-popup-wrapper" closeButton={false}>
                <div className="emp-gps-popup">
                  <div className="emp-gps-popup__head">
                    <span className="emp-gps-popup__dot" style={{ background: statusColor(bus.status) }} />
                    <b>{bus.bus_number}</b>
                    <span className={`emp-gps-popup__status emp-gps-popup__status--${bus.status.toLowerCase()}`}>
                      {bus.status}
                    </span>
                  </div>
                  <div className="emp-gps-popup__route">{bus.route}</div>
                  <div className="emp-gps-popup__grid">
                    <div><span>Shift</span><b>{bus.shift}</b></div>
                    <div><span>Driver</span><b>{bus.driver}</b></div>
                    <div><span>ETA</span><b>{bus.eta}</b></div>
                    <div><span>Speed</span><b>{bus.speed} km/h</b></div>
                  </div>
                  <button className="emp-gps-popup__track" onClick={(e) => { e.stopPropagation(); handleSelectBus(bus) }}>
                    <Navigation size={14} /> Track
                  </button>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>

        <div className="emp-map__live-badge">
          <span className="emp-live-badge__pulse" />
          Live tracking
        </div>
      </div>

      <aside className="emp-gps-sidebar">
        <div className="emp-gps-sidebar__card">
          <div className="emp-gps-sidebar__header">
            <h2><Bus size={18} /> Fleet Live</h2>
            <span className="emp-gps-sidebar__count">{buses.length} vehicles</span>
          </div>

          <div className="emp-gps-bus-list">
            {buses.map((bus) => {
              const isActive = bus.status === 'ACTIVE'
              return (
                <div
                  key={bus.bus_id}
                  className={`emp-gps-bus-item ${selectedBus?.bus_id === bus.bus_id ? 'emp-gps-bus-item--selected' : ''}`}
                  onClick={() => handleSelectBus(bus)}
                >
                  <div className="emp-gps-bus-item__header">
                    <div className={`emp-gps-bus-dot ${isActive ? 'emp-gps-bus-dot--active' : 'emp-gps-bus-dot--inactive'}`} />
                    <div className="emp-gps-bus-item__title">
                      <b>{bus.bus_number}</b>
                      <span>{bus.shift} · {bus.route}</span>
                    </div>
                    <span className={`emp-gps-status emp-gps-status--${bus.status.toLowerCase()}`}>
                      {bus.status}
                    </span>
                  </div>

                  <div className="emp-gps-bus-item__meta">
                    <span className="emp-gps-location">
                      <MapPin size={13} />
                      {bus.lat.toFixed(4)}, {bus.lng.toFixed(4)}
                    </span>
                    <span className="emp-gps-speed">
                      <Navigation size={13} />
                      {bus.speed} km/h
                    </span>
                  </div>

                  <div className="emp-gps-bus-item__footer">
                    <span className="emp-gps-driver">
                      <Users size={13} />
                      {bus.driver}
                    </span>
                    <span className="emp-gps-eta">
                      <Clock size={13} />
                      ETA {bus.eta}
                    </span>
                  </div>

                  {isActive && bus.occupancy > 0 && (
                    <div className="emp-gps-occupancy">
                      <div className="emp-gps-occupancy__label">
                        <Gauge size={12} />
                        <span>Occupancy</span>
                        <b>{bus.occupancy}%</b>
                      </div>
                      <div className="emp-gps-occupancy__track">
                        <div
                          className="emp-gps-occupancy__fill"
                          style={{
                            width: `${bus.occupancy}%`,
                            background: bus.occupancy > 85
                              ? 'linear-gradient(90deg,#f59e0b,#ef4444)'
                              : 'linear-gradient(90deg,#b91c1c,#d94a4a)',
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )
            })}

            {!buses.length && (
              <div className="emp-gps-empty">
                <MapPin size={24} />
                <p>No buses available.</p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </div>
  )
}
