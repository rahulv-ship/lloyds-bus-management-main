import { useState } from 'react'
import { Bell, Search, ChevronDown, Moon, Sun } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import ThemeToggle from './ThemeToggle'
import NotificationBell from './NotificationBell'
import { useSessionContext } from '../../hooks/SessionContext'
import './NewLayout.css'

export default function AppHeader() {
  const { session, logout } = useSessionContext()
  const navigate = useNavigate()
  const [profileOpen, setProfileOpen] = useState(false)

  const initials = (session?.user?.name || session?.user?.employee_name || 'E')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  const user = session?.user || {}
  const fullName = user.name || user.employee_name || 'Employee'
  const employeeId = user.employeeId || user.employee_id

  return (
    <header className="app-header">
      <div className="app-header__search">
        <Search size={18} className="app-header__search-icon" />
        <input
          type="text"
          placeholder=" "
          className="app-header__search-input"
        />
      </div>

      <div className="app-header__actions">
        <NotificationBell />
        <ThemeToggle />

        <div className="app-header__profile">
          <button
            type="button"
            className="app-header__profile-trigger"
            aria-expanded={profileOpen}
            aria-haspopup="true"
            onClick={() => setProfileOpen((v) => !v)}
          >
            <div className="app-header__avatar">{initials}</div>
            <div className="app-header__profile-text">
              <div className="app-header__profile-name">{fullName}</div>
              {employeeId && <div className="app-header__profile-id">Employee ID: {employeeId}</div>}
            </div>
            <ChevronDown size={16} className="app-header__profile-chevron" />
          </button>

          {profileOpen && (
            <div className="app-header__dropdown">
              <button type="button" className="app-header__dropdown-item" onClick={() => { setProfileOpen(false); navigate('/app/profile') }}>
                <User size={16} />
                <span>Profile</span>
              </button>
              <button type="button" className="app-header__dropdown-item" onClick={() => { setProfileOpen(false); navigate('/app/settings') }}>
                <Settings size={16} />
                <span>Settings</span>
              </button>
              <div className="app-header__dropdown-separator" />
              <button type="button" className="app-header__dropdown-item app-header__dropdown-item--danger" onClick={() => { setProfileOpen(false); logout() }}>
                <LogOut size={16} />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
