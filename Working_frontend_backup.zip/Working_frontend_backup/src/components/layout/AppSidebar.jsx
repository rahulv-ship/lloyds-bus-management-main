import { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Menu, X, FileText, Briefcase, Bus, MapPin } from 'lucide-react'
import { useSessionContext } from '../../hooks/SessionContext'
import './NewLayout.css'

const SECTIONS = [
  {
    title: 'My Assist',
    items: [
      { to: '/app/pass', label: 'My Bus_QR', icon: FileText },
      { to: '/app/book', label: 'Book Bus', icon: Briefcase },
      { to: '/app/bookings', label: 'My Bookings', icon: Bus },
      { to: '/app/gps', label: 'GPS', icon: MapPin },
    ],
  },
]

export default function AppSidebar() {
  const [rightOpen, setRightOpen] = useState(false)
  const location = useLocation()
  const { logout } = useSessionContext()

  return (
    <>
      <button
        type="button"
        className="sidebar__right-toggle"
        onClick={() => setRightOpen((v) => !v)}
        aria-label="Open menu"
      >
        ≡
      </button>

      {rightOpen && (
        <div className="sidebar-menu__overlay" onClick={() => setRightOpen(false)} />
      )}

      <aside className={`sidebar-menu ${rightOpen ? 'sidebar-menu--open' : ''}`}>
        <button type="button" className="sidebar-menu__close" onClick={() => setRightOpen(false)} aria-label="Close menu">
          <X size={20} />
        </button>
        <nav className="sidebar-menu__nav">
          {SECTIONS.map((section) => (
            <div key={section.title} className="sidebar-menu__section">
              <div className="sidebar-menu__section-title">
                <span>{section.title}</span>
              </div>
              <div className="sidebar-menu__items">
                {section.items.map((item) => {
                  const isActive = location.pathname === item.to ||
                    (item.to !== '/app/home' && location.pathname.startsWith(item.to))

                  return (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      className={({ isActive: navActive }) =>
                        `sidebar-menu__item ${navActive || isActive ? 'sidebar-menu__item--active' : ''}`
                      }
                      onClick={() => setRightOpen(false)}
                    >
                      <span className={`sidebar-menu__item-icon ${isActive ? 'sidebar-menu__item-icon--active' : ''}`}>
                        {item.icon && <item.icon size={18} />}
                      </span>
                      <span className="sidebar-menu__item-label">{item.label}</span>
                    </NavLink>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="sidebar-menu__footer">
          <button type="button" className="sidebar-menu__logout" onClick={logout} aria-label="Sign out">
            <X size={18} /> Logout
          </button>
        </div>
      </aside>
    </>
  )
}
